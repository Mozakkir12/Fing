<?php
// IP ঠিকানা সেট করা হচ্ছে
define('SERVER_IP', '192.168.110.192'); // যদি IP পাওয়া না যায় তবে 127.0.0.1 নেয়া হবে
define('SERVER_PORT', '7788');

define('MAX_THREADS', 32);

define('MYSQL_HOST', 'localhost:3306');
define('MYSQL_DB', 'Com_54');
define('MYSQL_PORT', '3306');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', 'root');

// PDO সংযোগের উদাহরণ
/*
try{
    $pdoConn = new PDO("mysql:host=".MYSQL_HOST, MYSQL_USER, MYSQL_PASS);
    $pdoConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdoConn->exec("use ".MYSQL_DB.";");
}catch(PDOException $e){
    echo $e->getMessage();
}
*/
?>