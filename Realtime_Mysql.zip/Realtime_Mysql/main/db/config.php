<?php
define('SERVER_IP', '192.168.110.140');
define('SERVER_PORT', '7788');

define('MAX_THREADS', 32);

define('MYSQL_HOST', 'localhost:3306');
define('MYSQL_DB', 'realtime');
define('MYSQL_PORT', '3306');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', 'root');

/*
try{
    $pdo = new PDO("mysql:host=".MYSQL_HOST,MYSQL_USER,MYSQL_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("use ".MYSQL_DB);
}catch(PDOException $e){
    echo $e->getMessage();
}
*/
?>