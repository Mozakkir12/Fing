-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 01, 2024 at 02:02 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `realtime`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_day`
--

CREATE TABLE `access_day` (
  `id` int(11) NOT NULL,
  `serial` varchar(12) COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `start_time1` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `end_time1` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `start_time2` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `end_time2` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `start_time3` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `end_time3` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `start_time4` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `end_time4` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `start_time5` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `end_time5` varchar(20) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Table structure for table `access_week`
--

CREATE TABLE `access_week` (
  `id` int(11) NOT NULL,
  `serial` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `monday` int(20) NOT NULL,
  `tuesday` int(20) NOT NULL,
  `wednesday` int(20) NOT NULL,
  `thursday` int(20) NOT NULL,
  `friday` int(20) NOT NULL,
  `saturday` int(20) NOT NULL,
  `sunday` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `id` int(100) NOT NULL,
  `enroll_id` int(100) NOT NULL,
  `mode` varchar(50) DEFAULT NULL,
  `event` varchar(50) DEFAULT NULL,
  `device_serial_num` varchar(50) DEFAULT NULL,
  `temperature` decimal(5,2) DEFAULT NULL,
  `image` blob DEFAULT NULL,
  `date` date DEFAULT NULL,
  `in_time` datetime DEFAULT NULL,
  `out_time` datetime DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `roll_id` varchar(50) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `late_time` time DEFAULT NULL,
  `early_time` time DEFAULT NULL,
  `los_time` time DEFAULT NULL,
  `over_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `attendance_records`
--


-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` int(100) NOT NULL,
  `branch_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(100) NOT NULL,
  `company_code` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `depertment`
--

CREATE TABLE `depertment` (
  `id` int(100) NOT NULL,
  `dept_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

CREATE TABLE `device` (
  `id` int(11) NOT NULL,
  `serial_num` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Table structure for table `dupbr`
--

CREATE TABLE `dupbr` (
  `id` int(11) NOT NULL,
  `branch_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dupdept`
--

CREATE TABLE `dupdept` (
  `id` int(11) NOT NULL,
  `dept_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `enrollinfo`
--

CREATE TABLE `enrollinfo` (
  `id` int(11) NOT NULL,
  `enroll_id` bigint(20) NOT NULL,
  `backupnum` int(11) DEFAULT NULL,
  `imagepath` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `signatures` mediumtext COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Table structure for table `machine_command`
--

CREATE TABLE `machine_command` (
  `id` int(11) NOT NULL,
  `serial` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `content` mediumtext COLLATE utf8mb4_bin DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `send_status` int(11) NOT NULL DEFAULT 0,
  `err_count` int(11) NOT NULL DEFAULT 0,
  `run_time` datetime DEFAULT NULL,
  `gmt_crate` datetime NOT NULL,
  `gmt_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `machine_command`
--

INSERT INTO `machine_command` (`id`, `serial`, `name`, `content`, `status`, `send_status`, `err_count`, `run_time`, `gmt_crate`, `gmt_modified`) VALUES
(5239, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 0, 1, 3, '2024-09-29 17:16:04', '2024-09-29 17:00:42', '2024-09-29 17:00:42'),
(5240, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":,\"backupnum\":0}', 0, 1, 3, '2024-09-29 17:22:33', '2024-09-29 17:00:57', '2024-09-29 17:00:57'),
(5241, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 1, '2024-09-29 17:22:56', '2024-09-29 17:01:06', '2024-09-29 17:01:06'),
(5242, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":0,\"record\":]}', 0, 1, 3, '2024-09-29 17:23:59', '2024-09-29 17:01:20', '2024-09-29 17:01:20'),
(5243, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-09-29 17:24:00', '2024-09-29 17:01:23', '2024-09-29 17:01:23'),
(5244, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 1, '2024-09-29 17:24:21', '2024-09-29 17:01:52', '2024-09-29 17:01:52'),
(5245, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":0,\"record\":]}', 0, 1, 3, '2024-09-29 17:25:24', '2024-09-29 17:02:11', '2024-09-29 17:02:11'),
(5246, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-09-29 17:25:25', '2024-09-29 17:02:58', '2024-09-29 17:02:58'),
(5247, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-09-29 17:25:28', '2024-09-29 17:14:04', '2024-09-29 17:14:04'),
(5248, 'GTLD190013', 'opendoor', '{\"cmd\":\"opendoor\",\"doornum\":1}', 1, 0, 0, '2024-09-29 17:25:28', '2024-09-29 17:14:10', '2024-09-29 17:14:10'),
(5249, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":0,\"record\":]}', 0, 1, 3, '2024-09-29 17:26:31', '2024-09-29 17:14:51', '2024-09-29 17:14:51'),
(5250, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-09-29 17:26:37', '2024-09-29 17:14:54', '2024-09-29 17:14:54'),
(5251, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":4,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 1, '2024-09-29 17:26:59', '2024-09-29 17:15:07', '2024-09-29 17:15:07'),
(5252, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-09-29 17:26:59', '2024-09-29 17:22:35', '2024-09-29 17:22:35'),
(5253, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-09-29 17:26:59', '2024-09-29 17:23:05', '2024-09-29 17:23:05'),
(5254, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":,\"backupnum\":4}', 0, 1, 3, '2024-09-29 17:28:02', '2024-09-29 17:25:54', '2024-09-29 17:25:54'),
(5255, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-09-29 17:28:04', '2024-09-29 17:26:49', '2024-09-29 17:26:49'),
(5256, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":0,\"record\":]}', 0, 1, 3, '2024-09-29 17:29:07', '2024-09-29 17:27:36', '2024-09-29 17:27:36'),
(5257, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-09-29 17:29:08', '2024-09-29 17:27:49', '2024-09-29 17:27:49'),
(5258, 'GTLD190013', 'opendoor', '{\"cmd\":\"opendoor\",\"doornum\":4}', 1, 0, 0, '2024-09-29 17:29:08', '2024-09-29 17:28:15', '2024-09-29 17:28:15'),
(5259, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-09-29 17:29:09', '2024-09-29 17:28:22', '2024-09-29 17:28:22'),
(5260, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":4}', 1, 0, 1, '2024-09-29 17:29:30', '2024-09-29 17:28:34', '2024-09-29 17:28:34'),
(5261, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":4}', 1, 0, 0, '2024-09-29 17:30:45', '2024-09-29 17:30:44', '2024-09-29 17:30:44'),
(5262, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-09-29 17:30:52', '2024-09-29 17:30:50', '2024-09-29 17:30:50'),
(5263, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":4,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-09-29 17:31:10', '2024-09-29 17:31:09', '2024-09-29 17:31:09'),
(5264, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-09-29 17:33:55', '2024-09-29 17:32:51', '2024-09-29 17:32:51'),
(5265, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-09-29 17:34:59', '2024-09-29 17:33:07', '2024-09-29 17:33:07'),
(5266, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-09-29 17:36:03', '2024-09-29 17:33:21', '2024-09-29 17:33:21'),
(5267, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":6,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-09-29 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-09-29 17:37:07', '2024-09-29 17:34:26', '2024-09-29 17:34:26'),
(5268, 'GTLD190013', 'setusername', '{\"cmd\":\"setuserinfo\",\"enrollid\":4,\"name\":\"\",\"backupnum\":0,\"admin\":4,\"record\":\"c51567008b89e25617c5f8411588d2c2003426c52489ab4ed8721745268adb75f87418440e86f389eabe791a478693bdc7d99b233886f3eddfdc8a5b34893bedd82e18c5308adc51f8b81903bc86e47dd80d3ad13d88ec81d8f24946b286bc8df8926ad89d848c99f9bfff03368a64a6f8f639c4468954f1d0b039076187352adceffe043f8aed51f8b45ac7a78b5cb91fffca44af867c9df8d25b6561873595d835fa0439842545fff5fd85(312)7525954238a368f3f58a28f18b295823f27b493f63571279f41fff4ff54265f6f22f78f40f(75)11678f1a0247b8a6641b0737d596b10c0410ddb8ee14623312a45c0d3265ed81cd103346b9a683152113cc91ec103365c9b9633732033071411163c1ebe13c2616927791a0537353c0615a511291ce915033112450901c4b54620481557195e388f090573121dea1(78)06040509070b0a12020f0e010d08030c11(13)d098\"}', 0, 1, 3, '2024-09-29 17:38:11', '2024-09-29 17:34:50', '2024-09-29 17:34:50'),
(5269, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-09-29 17:39:15', '2024-09-29 17:36:47', '2024-09-29 17:36:47'),
(5270, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-09-29 17:40:19', '2024-09-29 17:37:12', '2024-09-29 17:37:12'),
(5271, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-09-29 17:41:23', '2024-09-29 17:37:26', '2024-09-29 17:37:26'),
(5272, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-09-29 17:58:34', '2024-09-29 17:58:33', '2024-09-29 17:58:33'),
(5273, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-09-29 17:58:39', '2024-09-29 17:58:38', '2024-09-29 17:58:38'),
(5274, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"\",\"backupnum\":0,\"admin\":0,\"record\":\"c53563035bf8029288d3960f87f9aa7e304f880b58f85aa6a0d787164fe622c1d04bb6853e58aad9c11f48753df6eb35d0d1a7c897896b1d0017289946e54b49dec9b7034cfa635de56a8b0e2df77b7ed8d199890df8a37200db1ad11278939918974b4d31e643e1e0cfa8883ce4fbfddfc7d78572f9c419dda87c8ca775c46aff3656850eb8551e07cbfa471298146508cd8a8662e6ea29cfcba70550e6e2a1d091b78826bb4285f872578562f9c35ed1e2ca99b58bd3751fc39b8315c843ce08d567ca57fb3431e8324a47128a394dff7e17428b8b09810ffff6c37ce8b1e6dfc9a7079b8c0ab527ffc94cb3652389f8025705ab6513c5f841fa03428c03bdf8ba2802b38c33d527fa1842398c2c15f9c3fbc8558bf465ff3e1c50528bdca1f87ff851d18b14ce1fff6b8453742a7defc7f8854f74d2aeefc9a804c443db01ff7e37d3c0342b22ff76370fa243db45fa4bf98dc043f371ff3e288bb97413cdff0828c5517484aa9ff3f8522e44ece5e7cbfa184944a4f6aff5f9dab44d3b9617c3fac9b44d6bd21ffffc85404d23e5f8be5b44364d4c31f9c3fa88444d2451f8c1f90cd64bad31efffca84(56)522543439af43442643713354523f62f31a6228448f7445544ff526f32854313f53216636f5f8355574225f5235463f34f8f744f3f237214733263f7f111ff5f4f333470f52ff7fff7ff2ffff1ff3117ffff71ff1f28ff6f8311722f1f3032f6f131fff1ff1ff1f1fffff1fff10f(2)1e63cc5a1212d4a4763a20c3eab3b73e01e1e78df3500122bc86b127025063a6381a2290bb72580e3370ce755d061212e992645b043391b39b644302d9826f2a346354c37a2e117288729c054514de71ab1022730682316441166671555c03c3b9b0ed4c2043037020180012b980ae231052cc71113861147e93526072138561e274111044807b2899038ba14177105043b2d17412014571cc661155b4b11d26060299a2bd4220301382024130625693c2063000ce840a0b04061517020908010e131b0c1416071f1d1c0f2010210d242f2a292cb260\"}', 0, 1, 3, '2024-09-30 17:46:17', '2024-09-29 18:02:44', '2024-09-29 18:02:44'),
(5275, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":4,\"name\":\"\",\"backupnum\":0,\"admin\":0,\"record\":\"c51567008b89e25617c5f8411588d2c2003426c52489ab4ed8721745268adb75f87418440e86f389eabe791a478693bdc7d99b233886f3eddfdc8a5b34893bedd82e18c5308adc51f8b81903bc86e47dd80d3ad13d88ec81d8f24946b286bc8df8926ad89d848c99f9bfff03368a64a6f8f639c4468954f1d0b039076187352adceffe043f8aed51f8b45ac7a78b5cb91fffca44af867c9df8d25b6561873595d835fa0439842545fff5fd85(312)7525954238a368f3f58a28f18b295823f27b493f63571279f41fff4ff54265f6f22f78f40f(75)11678f1a0247b8a6641b0737d596b10c0410ddb8ee14623312a45c0d3265ed81cd103346b9a683152113cc91ec103365c9b9633732033071411163c1ebe13c2616927791a0537353c0615a511291ce915033112450901c4b54620481557195e388f090573121dea1(78)06040509070b0a12020f0e010d08030c11(13)d098\"}', 0, 1, 3, '2024-09-30 17:47:21', '2024-09-29 18:02:44', '2024-09-29 18:02:44'),
(5276, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-09-30 17:48:25', '2024-09-29 19:14:36', '2024-09-29 19:14:36'),
(5277, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-09-30 17:49:29', '2024-09-30 05:18:54', '2024-09-30 05:18:54'),
(5278, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-09-30 17:50:33', '2024-09-30 05:19:05', '2024-09-30 05:19:05'),
(5279, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-09-30 17:51:37', '2024-09-30 05:19:21', '2024-09-30 05:19:21'),
(5280, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 0, 1, 3, '2024-09-30 17:52:41', '2024-09-30 05:19:31', '2024-09-30 05:19:31'),
(5281, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":4,\"name\":\"\"}]}', 0, 1, 3, '2024-09-30 17:53:45', '2024-09-30 05:19:47', '2024-09-30 05:19:47'),
(5282, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-09-30 17:54:49', '2024-09-30 05:20:14', '2024-09-30 05:20:14'),
(5283, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-09-30 17:55:53', '2024-09-30 08:36:19', '2024-09-30 08:36:19'),
(5284, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-09-30 17:56:57', '2024-09-30 08:36:28', '2024-09-30 08:36:28'),
(5285, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 1, '2024-09-30 17:57:20', '2024-09-30 08:36:34', '2024-09-30 08:36:34'),
(5286, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 0, 1, 3, '2024-09-30 17:58:23', '2024-09-30 08:37:17', '2024-09-30 08:37:17'),
(5287, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-09-30 17:59:27', '2024-09-30 08:37:23', '2024-09-30 08:37:23'),
(5288, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 0, 1, 3, '2024-09-30 18:12:40', '2024-09-30 08:37:25', '2024-09-30 08:37:25'),
(5289, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 2, '2024-09-30 18:20:24', '2024-09-30 17:46:34', '2024-09-30 17:46:34'),
(5290, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-09-30 18:20:24', '2024-09-30 17:46:47', '2024-09-30 17:46:47'),
(5291, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-09-30 18:20:24', '2024-09-30 17:46:51', '2024-09-30 17:46:51'),
(5292, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-09-30 18:20:25', '2024-09-30 17:47:01', '2024-09-30 17:47:01'),
(5293, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-09-30 18:20:25', '2024-09-30 17:47:31', '2024-09-30 17:47:31'),
(5294, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-09-30 18:20:25', '2024-09-30 17:47:39', '2024-09-30 17:47:39'),
(5295, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-09-30 18:20:26', '2024-09-30 17:47:41', '2024-09-30 17:47:41'),
(5296, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":4,\"name\":\"\"}]}', 1, 0, 0, '2024-09-30 18:20:26', '2024-09-30 17:47:44', '2024-09-30 17:47:44'),
(5297, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":4,\"name\":\"\"}]}', 1, 0, 0, '2024-09-30 18:20:26', '2024-09-30 17:47:46', '2024-09-30 17:47:46'),
(5298, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-09-30 18:20:27', '2024-09-30 17:47:50', '2024-09-30 17:47:50'),
(5299, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":1,\"backupnum\":0}', 0, 1, 3, '2024-09-30 18:21:30', '2024-09-30 17:47:53', '2024-09-30 17:47:53'),
(5300, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":4,\"backupnum\":0}', 0, 1, 3, '2024-09-30 18:22:34', '2024-09-30 17:47:53', '2024-09-30 17:47:53'),
(5301, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-09-30 18:22:35', '2024-09-30 17:47:58', '2024-09-30 17:47:58'),
(5302, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-09-30 18:22:35', '2024-09-30 17:48:06', '2024-09-30 17:48:06'),
(5303, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 1, '2024-09-30 18:22:57', '2024-09-30 17:48:17', '2024-09-30 17:48:17'),
(5304, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":5,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-09-30 18:22:57', '2024-09-30 17:49:11', '2024-09-30 17:49:11'),
(5305, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":6,\"weekzone\":1,\"group\":4,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-09-30 18:22:57', '2024-09-30 17:50:16', '2024-09-30 17:50:16'),
(5306, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":7,\"name\":,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-09-30 18:24:00', '2024-09-30 18:03:19', '2024-09-30 18:03:19'),
(5307, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":8,\"name\":Name,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-09-30 18:25:04', '2024-09-30 18:05:15', '2024-09-30 18:05:15'),
(5308, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":8,\"name\":Mozakkir,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-09-30 18:26:08', '2024-09-30 18:05:43', '2024-09-30 18:05:43'),
(5309, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"\",\"backupnum\":0,\"admin\":0,\"record\":\"c53563035bf8029288d3960f87f9aa7e304f880b58f85aa6a0d787164fe622c1d04bb6853e58aad9c11f48753df6eb35d0d1a7c897896b1d0017289946e54b49dec9b7034cfa635de56a8b0e2df77b7ed8d199890df8a37200db1ad11278939918974b4d31e643e1e0cfa8883ce4fbfddfc7d78572f9c419dda87c8ca775c46aff3656850eb8551e07cbfa471298146508cd8a8662e6ea29cfcba70550e6e2a1d091b78826bb4285f872578562f9c35ed1e2ca99b58bd3751fc39b8315c843ce08d567ca57fb3431e8324a47128a394dff7e17428b8b09810ffff6c37ce8b1e6dfc9a7079b8c0ab527ffc94cb3652389f8025705ab6513c5f841fa03428c03bdf8ba2802b38c33d527fa1842398c2c15f9c3fbc8558bf465ff3e1c50528bdca1f87ff851d18b14ce1fff6b8453742a7defc7f8854f74d2aeefc9a804c443db01ff7e37d3c0342b22ff76370fa243db45fa4bf98dc043f371ff3e288bb97413cdff0828c5517484aa9ff3f8522e44ece5e7cbfa184944a4f6aff5f9dab44d3b9617c3fac9b44d6bd21ffffc85404d23e5f8be5b44364d4c31f9c3fa88444d2451f8c1f90cd64bad31efffca84(56)522543439af43442643713354523f62f31a6228448f7445544ff526f32854313f53216636f5f8355574225f5235463f34f8f744f3f237214733263f7f111ff5f4f333470f52ff7fff7ff2ffff1ff3117ffff71ff1f28ff6f8311722f1f3032f6f131fff1ff1ff1f1fffff1fff10f(2)1e63cc5a1212d4a4763a20c3eab3b73e01e1e78df3500122bc86b127025063a6381a2290bb72580e3370ce755d061212e992645b043391b39b644302d9826f2a346354c37a2e117288729c054514de71ab1022730682316441166671555c03c3b9b0ed4c2043037020180012b980ae231052cc71113861147e93526072138561e274111044807b2899038ba14177105043b2d17412014571cc661155b4b11d26060299a2bd4220301382024130625693c2063000ce840a0b04061517020908010e131b0c1416071f1d1c0f2010210d242f2a292cb260\"}', 1, 0, 0, '2024-09-30 18:26:09', '2024-09-30 18:09:48', '2024-09-30 18:09:48'),
(5310, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":4,\"name\":\"\",\"backupnum\":0,\"admin\":0,\"record\":\"c51567008b89e25617c5f8411588d2c2003426c52489ab4ed8721745268adb75f87418440e86f389eabe791a478693bdc7d99b233886f3eddfdc8a5b34893bedd82e18c5308adc51f8b81903bc86e47dd80d3ad13d88ec81d8f24946b286bc8df8926ad89d848c99f9bfff03368a64a6f8f639c4468954f1d0b039076187352adceffe043f8aed51f8b45ac7a78b5cb91fffca44af867c9df8d25b6561873595d835fa0439842545fff5fd85(312)7525954238a368f3f58a28f18b295823f27b493f63571279f41fff4ff54265f6f22f78f40f(75)11678f1a0247b8a6641b0737d596b10c0410ddb8ee14623312a45c0d3265ed81cd103346b9a683152113cc91ec103365c9b9633732033071411163c1ebe13c2616927791a0537353c0615a511291ce915033112450901c4b54620481557195e388f090573121dea1(78)06040509070b0a12020f0e010d08030c11(13)d098\"}', 1, 0, 0, '2024-09-30 18:26:10', '2024-09-30 18:09:48', '2024-09-30 18:09:48'),
(5311, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":8,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-09-30 18:26:10', '2024-09-30 18:10:36', '2024-09-30 18:10:36'),
(5312, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"\"},{\"enrollid\":4,\"name\":\"\"},{\"enrollid\":5,\"name\":\"Mozakkir\"},{\"enrollid\":8,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-09-30 18:26:10', '2024-09-30 18:11:00', '2024-09-30 18:11:00'),
(5313, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":9,\"name\":Mozakkir,\"weekzone\":1,\"group\":8,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-09-30 18:27:14', '2024-09-30 18:11:39', '2024-09-30 18:11:39'),
(5314, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-09-30 18:27:16', '2024-09-30 18:15:42', '2024-09-30 18:15:42'),
(5315, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":4,\"backupnum\":13}', 1, 0, 1, '2024-09-30 18:27:38', '2024-09-30 18:15:44', '2024-09-30 18:15:44'),
(5316, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":5,\"backupnum\":13}', 1, 0, 0, '2024-09-30 18:27:39', '2024-09-30 18:15:46', '2024-09-30 18:15:46'),
(5317, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":8,\"backupnum\":13}', 1, 0, 0, '2024-09-30 18:27:40', '2024-09-30 18:15:48', '2024-09-30 18:15:48'),
(5318, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":Mozakkir,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-09-30 18:30:44', '2024-09-30 18:16:12', '2024-09-30 18:16:12'),
(5319, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":Mozakkir,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-09-30 18:31:48', '2024-09-30 18:21:21', '2024-09-30 18:21:21'),
(5320, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-09-30 18:31:50', '2024-09-30 18:31:13', '2024-09-30 18:31:13'),
(5321, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-09-30 18:31:50', '2024-09-30 18:31:42', '2024-09-30 18:31:42'),
(5322, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-09-30 18:32:33', '2024-09-30 18:32:31', '2024-09-30 18:32:31'),
(5323, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-09-30 18:36:55', '2024-09-30 18:36:54', '2024-09-30 18:36:54'),
(5324, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-09-30 18:37:01', '2024-09-30 18:37:00', '2024-09-30 18:37:00'),
(5325, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:02:53', '2024-10-03 13:01:49', '2024-10-03 13:01:49'),
(5326, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:05:04', '2024-10-03 13:02:01', '2024-10-03 13:02:01'),
(5327, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:06:08', '2024-10-03 13:02:06', '2024-10-03 13:02:06'),
(5328, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:07:12', '2024-10-03 13:02:10', '2024-10-03 13:02:10'),
(5329, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:12:27', '2024-10-03 13:02:54', '2024-10-03 13:02:54'),
(5330, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:13:31', '2024-10-03 13:04:42', '2024-10-03 13:04:42'),
(5331, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:14:35', '2024-10-03 13:13:16', '2024-10-03 13:13:16'),
(5332, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:15:39', '2024-10-03 13:13:24', '2024-10-03 13:13:24'),
(5333, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 13:16:43', '2024-10-03 13:14:12', '2024-10-03 13:14:12'),
(5334, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 1, '2024-10-03 13:17:06', '2024-10-03 13:14:27', '2024-10-03 13:14:27'),
(5335, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:22:36', '2024-10-03 13:20:31', '2024-10-03 13:20:31'),
(5336, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:22:37', '2024-10-03 13:21:23', '2024-10-03 13:21:23'),
(5337, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:22:37', '2024-10-03 13:21:26', '2024-10-03 13:21:26'),
(5338, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-03 13:22:38', '2024-10-03 13:21:44', '2024-10-03 13:21:44'),
(5339, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-03 00:00:00\",\"endtime\":\"2024-10-12 00:00:00\"}]}', 1, 0, 0, '2024-10-03 13:23:25', '2024-10-03 13:23:24', '2024-10-03 13:23:24'),
(5340, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 13:23:30', '2024-10-03 13:23:30', '2024-10-03 13:23:30'),
(5341, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:25:10', '2024-10-03 13:24:07', '2024-10-03 13:24:07'),
(5342, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:30:14', '2024-10-03 13:24:09', '2024-10-03 13:24:09'),
(5343, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 0, 1, 3, '2024-10-03 13:32:26', '2024-10-03 13:24:31', '2024-10-03 13:24:31'),
(5344, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 13:33:30', '2024-10-03 13:24:45', '2024-10-03 13:24:45'),
(5345, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"Mozakkir\",\"backupnum\":0,\"admin\":0,\"record\":\"c523660054856b0de7c7770554887b3590ff984b5186eb42d049a787ca84e369febff88eb9849b7af8bffa8e4985c3a6e7c9c6c4bb84bbaef8023acb428763b2c84fa7c82f880c0ac8d1a9091a88d41a011949cc42858466d7c3f7043586bc61e0cbc807378674bec845c808258834e1d8c9cc061688b4e9d8cd7a8652879321e0ffa7468e8b92a927fffa48808a03112fcf778b278bf335f8b5f6c65c890b3a089978582389638de122e7a39c89e3c10057281ca68a13d2e75938f09889b3d5089ae7a4608a5bf2d222ca9804895c05011b28154e8afbfde4a86b4d1888c45e18d547c99588dcc10d6c4ac6598bb4caff7e4c452487ed5ee7c5f9845f878ae6cfffbac8b4863cb90ebe1886b484a402f8825784be84bc1eff3e1787(200)612432f324133543f571f43356913119243fa52531383335541372337f3542523f727434775432556f23a1b1494274f3f16f2a564126764426f624fff4555f3381f63fff(44)1e667d0a1111d99299061080e8932b2a11708b729b0a1451e872775e0100e985b05200229c784e4d0040a8791a2f13408182cb544170d1a1104d0021aa879b211163908139762070cd86b9094280edc110491111a78c772a02b289a13a27606191719b0d0351de713024026072a6fd1d71229ea2940d12e5cd826b4c5161e4819c625212d872ea4c136204613a155094ebb3e54d41d1eb718e0d6132ee71cf38114023832139204032a272324a7a05c1a36b5a62416108091b07191417011c150b130d160e0f02181f0c2011051a0a0003061d1229f9\"}', 1, 0, 2, '2024-10-03 13:34:14', '2024-10-03 13:24:47', '2024-10-03 13:24:47'),
(5346, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":1,\"backupnum\":0}', 1, 0, 0, '2024-10-03 13:34:14', '2024-10-03 13:24:50', '2024-10-03 13:24:50'),
(5347, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":1,\"backupnum\":0}', 1, 0, 0, '2024-10-03 13:34:15', '2024-10-03 13:25:03', '2024-10-03 13:25:03'),
(5348, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:34:15', '2024-10-03 13:25:11', '2024-10-03 13:25:11'),
(5349, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:34:16', '2024-10-03 13:25:14', '2024-10-03 13:25:14'),
(5350, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:34:16', '2024-10-03 13:30:42', '2024-10-03 13:30:42'),
(5351, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:34:16', '2024-10-03 13:30:47', '2024-10-03 13:30:47'),
(5352, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:34:17', '2024-10-03 13:32:02', '2024-10-03 13:32:02'),
(5353, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 2, '2024-10-03 13:35:03', '2024-10-03 13:32:08', '2024-10-03 13:32:08'),
(5354, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:36:06', '2024-10-03 13:32:41', '2024-10-03 13:32:41'),
(5355, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 2, '2024-10-03 13:36:49', '2024-10-03 13:32:45', '2024-10-03 13:32:45'),
(5356, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 0, '2024-10-03 13:36:49', '2024-10-03 13:33:02', '2024-10-03 13:33:02'),
(5357, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:36:50', '2024-10-03 13:33:10', '2024-10-03 13:33:10'),
(5358, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:36:50', '2024-10-03 13:33:13', '2024-10-03 13:33:13'),
(5359, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-03 13:36:51', '2024-10-03 13:33:27', '2024-10-03 13:33:27'),
(5360, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-03 13:36:51', '2024-10-03 13:34:14', '2024-10-03 13:34:14'),
(5361, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:36:51', '2024-10-03 13:35:07', '2024-10-03 13:35:07'),
(5362, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:36:51', '2024-10-03 13:35:11', '2024-10-03 13:35:11'),
(5363, 'GTLD190013', 'getdevlock', '{\"cmd\":\"getdevlock\"}', 0, 1, 3, '2024-10-03 13:39:25', '2024-10-03 13:35:19', '2024-10-03 13:35:19'),
(5364, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 1, '2024-10-03 13:39:47', '2024-10-03 13:35:25', '2024-10-03 13:35:25'),
(5365, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:39:48', '2024-10-03 13:35:28', '2024-10-03 13:35:28'),
(5366, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-10-03 13:39:48', '2024-10-03 13:35:34', '2024-10-03 13:35:34'),
(5367, 'GTLD190013', 'opendoor', '{\"cmd\":\"opendoor\",\"doornum\":1}', 1, 0, 0, '2024-10-03 13:39:48', '2024-10-03 13:35:38', '2024-10-03 13:35:38'),
(5368, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:39:49', '2024-10-03 13:35:46', '2024-10-03 13:35:46'),
(5369, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":1,\"backupnum\":0}', 0, 1, 3, '2024-10-03 13:40:52', '2024-10-03 13:35:48', '2024-10-03 13:35:48'),
(5370, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"\",\"backupnum\":0,\"admin\":0,\"record\":\"c523660054856b0de7c7770554887b3590ff984b5186eb42d049a787ca84e369febff88eb9849b7af8bffa8e4985c3a6e7c9c6c4bb84bbaef8023acb428763b2c84fa7c82f880c0ac8d1a9091a88d41a011949cc42858466d7c3f7043586bc61e0cbc807378674bec845c808258834e1d8c9cc061688b4e9d8cd7a8652879321e0ffa7468e8b92a927fffa48808a03112fcf778b278bf335f8b5f6c65c890b3a089978582389638de122e7a39c89e3c10057281ca68a13d2e75938f09889b3d5089ae7a4608a5bf2d222ca9804895c05011b28154e8afbfde4a86b4d1888c45e18d547c99588dcc10d6c4ac6598bb4caff7e4c452487ed5ee7c5f9845f878ae6cfffbac8b4863cb90ebe1886b484a402f8825784be84bc1eff3e1787(200)612432f324133543f571f43356913119243fa52531383335541372337f3542523f727434775432556f23a1b1494274f3f16f2a564126764426f624fff4555f3381f63fff(44)1e667d0a1111d99299061080e8932b2a11708b729b0a1451e872775e0100e985b05200229c784e4d0040a8791a2f13408182cb544170d1a1104d0021aa879b211163908139762070cd86b9094280edc110491111a78c772a02b289a13a27606191719b0d0351de713024026072a6fd1d71229ea2940d12e5cd826b4c5161e4819c625212d872ea4c136204613a155094ebb3e54d41d1eb718e0d6132ee71cf38114023832139204032a272324a7a05c1a36b5a62416108091b07191417011c150b130d160e0f02181f0c2011051a0a0003061d1229f9\"}', 1, 0, 0, '2024-10-03 13:40:54', '2024-10-03 13:35:50', '2024-10-03 13:35:50'),
(5371, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-10-03 13:40:54', '2024-10-03 13:35:52', '2024-10-03 13:35:52'),
(5372, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-03 13:40:54', '2024-10-03 13:35:55', '2024-10-03 13:35:55'),
(5373, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-03 13:44:15', '2024-10-03 13:38:25', '2024-10-03 13:38:25'),
(5374, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-03 13:44:17', '2024-10-03 13:39:23', '2024-10-03 13:39:23'),
(5375, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-03 13:44:17', '2024-10-03 13:39:32', '2024-10-03 13:39:32'),
(5376, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 13:44:17', '2024-10-03 13:40:01', '2024-10-03 13:40:01'),
(5377, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 1, '2024-10-03 13:45:42', '2024-10-03 13:40:17', '2024-10-03 13:40:17'),
(5378, 'GTLD190013', 'getdevlock', '{\"cmd\":\"getdevlock\"}', 0, 1, 3, '2024-10-03 13:46:45', '2024-10-03 13:40:58', '2024-10-03 13:40:58'),
(5379, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 13:47:49', '2024-10-03 13:41:22', '2024-10-03 13:41:22'),
(5380, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:48:53', '2024-10-03 13:41:37', '2024-10-03 13:41:37'),
(5381, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 0, 1, 3, '2024-10-03 13:49:57', '2024-10-03 13:41:42', '2024-10-03 13:41:42'),
(5382, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:51:01', '2024-10-03 13:42:11', '2024-10-03 13:42:11'),
(5383, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:52:05', '2024-10-03 13:43:21', '2024-10-03 13:43:21'),
(5384, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-03 13:53:09', '2024-10-03 13:43:26', '2024-10-03 13:43:26'),
(5385, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-03 13:54:13', '2024-10-03 13:46:01', '2024-10-03 13:46:01'),
(5386, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 13:55:17', '2024-10-03 13:46:24', '2024-10-03 13:46:24'),
(5387, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 13:56:21', '2024-10-03 13:46:35', '2024-10-03 13:46:35'),
(5388, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:57:25', '2024-10-03 13:47:06', '2024-10-03 13:47:06'),
(5389, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:58:29', '2024-10-03 13:47:35', '2024-10-03 13:47:35'),
(5390, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 13:59:33', '2024-10-03 13:47:51', '2024-10-03 13:47:51'),
(5391, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 14:00:37', '2024-10-03 13:48:03', '2024-10-03 13:48:03'),
(5392, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 14:01:41', '2024-10-03 13:48:17', '2024-10-03 13:48:17'),
(5393, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 14:02:45', '2024-10-03 13:48:22', '2024-10-03 13:48:22'),
(5394, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 14:03:49', '2024-10-03 13:48:33', '2024-10-03 13:48:33'),
(5395, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 14:04:53', '2024-10-03 13:48:45', '2024-10-03 13:48:45'),
(5396, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 14:06:12', '2024-10-03 13:48:52', '2024-10-03 13:48:52'),
(5397, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 2, '2024-10-03 14:06:55', '2024-10-03 13:48:55', '2024-10-03 13:48:55'),
(5398, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 1, '2024-10-03 14:07:18', '2024-10-03 13:48:59', '2024-10-03 13:48:59'),
(5399, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-03 14:07:19', '2024-10-03 13:51:08', '2024-10-03 13:51:08'),
(5400, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-03 14:07:19', '2024-10-03 13:52:13', '2024-10-03 13:52:13'),
(5401, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":1,\"backupnum\":0}', 0, 1, 3, '2024-10-03 14:08:22', '2024-10-03 13:52:16', '2024-10-03 13:52:16'),
(5402, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-10-03 14:08:23', '2024-10-03 13:52:30', '2024-10-03 13:52:30'),
(5403, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-03 14:08:25', '2024-10-03 13:53:08', '2024-10-03 13:53:08'),
(5404, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-03 14:08:25', '2024-10-03 13:53:40', '2024-10-03 13:53:40'),
(5405, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:08:26', '2024-10-03 13:53:57', '2024-10-03 13:53:57'),
(5406, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-10-03 14:08:26', '2024-10-03 13:54:20', '2024-10-03 13:54:20'),
(5407, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:08:26', '2024-10-03 13:54:50', '2024-10-03 13:54:50'),
(5408, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"Mozakkir\",\"backupnum\":0,\"admin\":0,\"record\":\"c51960008088a31ee7c9a7476786e341d7cbb7868a8973b1384f98895586bbc9d88fb7875887a3d998d5974f298ae3d9f8745806528603dadfcbb70656880bf1b8d9881943867451d00fa7873586ecaad0d199c94d89f4b1e5687b4b2287b4bd08976a8e628944b2d1e4cb4f1687fcc510d939ce38859d01e049c8471c87951210d3688a76891d85d5e87d8b1c8795a1d04b59868f8b3ae10ffff983bd849c8dff3e36c82886bd75d7cbaa065b8a75b1f8322985a4846c51fa4bf80dac8b9c6d1fff9a4a3b85556dcfc7f805(280)377861344a45344253229624547351245467f473245239222132561f393262747433f62975334462243235543369f67f(64)1560194b341361863a531445307399321074e8a3ec52030223935d0e1211d99232190354eeb37a0a2451e8713a2a22708c827a2a207188719a6c3363ea82655f053471b2282e35607b711d0a5312ec719c013525de71c11e3102a6a1732a443354d24b2e19027991bc043153e7813060333577817d04300506622f689324aea2(54)07040b0d090c080f03020a0601001410110e051317(9)02a9\"}', 1, 0, 0, '2024-10-03 14:08:27', '2024-10-03 13:54:55', '2024-10-03 13:54:55'),
(5409, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-03 14:08:28', '2024-10-03 13:55:01', '2024-10-03 13:55:01'),
(5410, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-10-03 14:08:28', '2024-10-03 13:55:37', '2024-10-03 13:55:37'),
(5411, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":5,\"backupnum\":0}', 0, 1, 3, '2024-10-03 14:09:31', '2024-10-03 13:57:25', '2024-10-03 13:57:25'),
(5412, 'GTLD190013', 'getdevlock', '{\"cmd\":\"getdevlock\"}', 0, 1, 3, '2024-10-03 14:10:35', '2024-10-03 13:58:38', '2024-10-03 13:58:38'),
(5413, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":5,\"name\":\"Trrygt\"}]}', 0, 1, 3, '2024-10-03 14:12:12', '2024-10-03 13:58:49', '2024-10-03 13:58:49'),
(5414, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 14:15:16', '2024-10-03 13:58:53', '2024-10-03 13:58:53'),
(5415, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-03 14:16:20', '2024-10-03 13:59:28', '2024-10-03 13:59:28'),
(5416, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":5,\"backupnum\":13}', 1, 0, 0, '2024-10-03 14:16:22', '2024-10-03 13:59:30', '2024-10-03 13:59:30'),
(5417, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-03 14:17:25', '2024-10-03 14:00:22', '2024-10-03 14:00:22'),
(5418, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 14:25:17', '2024-10-03 14:00:27', '2024-10-03 14:00:27'),
(5419, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-03 14:30:20', '2024-10-03 14:01:12', '2024-10-03 14:01:12'),
(5420, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 14:31:24', '2024-10-03 14:01:16', '2024-10-03 14:01:16'),
(5421, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-03 14:32:28', '2024-10-03 14:01:36', '2024-10-03 14:01:36'),
(5422, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 1, 0, 2, '2024-10-03 14:56:30', '2024-10-03 14:01:51', '2024-10-03 14:01:51'),
(5423, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:56:31', '2024-10-03 14:02:06', '2024-10-03 14:02:06'),
(5424, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":2,\"name\":\"Mozakkir\",\"backupnum\":0,\"admin\":0,\"record\":\"c51367008c881a820fc9f9c7a688c2aebff7f88320890abdf83e17c285872b0e37cbf5ca99898b5107fa08411986cb7d093e281a21870bad007fc6863b84fbeecfc5a5459987dc090001b6429a88f401e079d8439589fc55087e18c393889469e88028439088fd19f83e0b844584eb45d7ffc4c29785b4c1f8387a4a94870cd1cf7a1a438085bd0ef989fc8b8386552df949fc08b5846b99ff7ff803(328)016b62278df3354fa561774b96991b32414f31a7173565f496f23132bff4f3bf(80)0e67ef5e623376616f3a22323660cf5a5441a986b55c53d1b852f82123919980002f1243628083164302b5a06d14151698513021855072a28d2563539d80c00d4005aa806d0c71610380dd4a204826c26d0053522570(96)06080503090b0f070e0401121102(16)ed7d\"}', 1, 0, 0, '2024-10-03 14:56:31', '2024-10-03 14:02:07', '2024-10-03 14:02:07'),
(5425, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":2,\"backupnum\":0}', 1, 0, 0, '2024-10-03 14:56:31', '2024-10-03 14:02:19', '2024-10-03 14:02:19'),
(5426, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-03 14:56:32', '2024-10-03 14:02:21', '2024-10-03 14:02:21'),
(5427, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 1, '2024-10-03 14:56:53', '2024-10-03 14:02:25', '2024-10-03 14:02:25'),
(5428, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:56:54', '2024-10-03 14:02:42', '2024-10-03 14:02:42'),
(5429, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":2,\"backupnum\":13}', 1, 0, 0, '2024-10-03 14:56:55', '2024-10-03 14:03:16', '2024-10-03 14:03:16'),
(5430, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-03 14:56:55', '2024-10-03 14:03:38', '2024-10-03 14:03:38'),
(5431, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:56:56', '2024-10-03 14:03:43', '2024-10-03 14:03:43'),
(5432, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:56:56', '2024-10-03 14:03:54', '2024-10-03 14:03:54'),
(5433, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":2,\"backupnum\":13}', 1, 0, 0, '2024-10-03 14:56:57', '2024-10-03 14:04:20', '2024-10-03 14:04:20'),
(5434, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-03 14:56:57', '2024-10-03 14:04:41', '2024-10-03 14:04:41'),
(5435, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:56:58', '2024-10-03 14:04:45', '2024-10-03 14:04:45'),
(5436, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:56:58', '2024-10-03 14:06:02', '2024-10-03 14:06:02'),
(5437, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:56:58', '2024-10-03 14:06:27', '2024-10-03 14:06:27'),
(5438, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":1,\"backupnum\":0}', 0, 1, 3, '2024-10-03 14:58:01', '2024-10-03 14:06:33', '2024-10-03 14:06:33'),
(5439, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-10-03 14:58:03', '2024-10-03 14:06:59', '2024-10-03 14:06:59'),
(5440, 'GTLD190013', 'opendoor', '{\"cmd\":\"opendoor\",\"doornum\":1}', 1, 0, 0, '2024-10-03 14:58:03', '2024-10-03 14:07:03', '2024-10-03 14:07:03'),
(5441, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:04', '2024-10-03 14:07:08', '2024-10-03 14:07:08'),
(5442, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:04', '2024-10-03 14:07:10', '2024-10-03 14:07:10'),
(5443, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:05', '2024-10-03 14:07:39', '2024-10-03 14:07:39'),
(5444, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:05', '2024-10-03 14:07:52', '2024-10-03 14:07:52'),
(5445, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:05', '2024-10-03 14:08:03', '2024-10-03 14:08:03'),
(5446, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-03 14:58:06', '2024-10-03 14:08:09', '2024-10-03 14:08:09'),
(5447, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:07', '2024-10-03 14:08:20', '2024-10-03 14:08:20'),
(5448, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:07', '2024-10-03 14:09:25', '2024-10-03 14:09:25'),
(5449, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-10-03 14:58:08', '2024-10-03 14:09:55', '2024-10-03 14:09:55'),
(5450, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"\",\"backupnum\":0,\"admin\":0,\"record\":\"c52661008f8a227d0fc5f8427f87aad2e7c9b8086685cae6dfcda887d3844361febe2a0487886359304d99485786a38590d597102889f379e03258055184fb92d84ba7855385bb89d891b7885b871392a0d78817cf844395fe7e29c49787f4110857289240858c15d051a787ba8b3c2ed7c388865e886456d9a2ca984888fc51e5aa7b0d31860c72d0d198c810872c66011b19d01f86d47600d759cdc18b7c69d7c3f843b48b5ca117fe2a833384dccde0cbb90673884d25d5ea8d0d1786d54dd08d68855989c549ff722a4627876bfdd8e0e85c9f87bc3d081ae8a6c083d3f1ff7e478bb383c45af84237c526861d29c849a8850f86d62e07c9fb062e848d31e7c7b745a484d52eff364704c3836bc1ff7e474ebb839c85fec026834083cd12cfc3f9843f8abd2df983fc86588a6d7dff3e1a8d(176)757a3316461373ff6465236383255f322244452544562391ff83244b357624f02f629f74f37235855332743726f2953343afff9551f64485745252f53377fa6fa6f51f1f3235ff8236f6ff82f11f07(33)1e61ac5a2210e8944f4d0030b789995a1492c793f15210014087f2500012bb847124026060a6580e13a1c982652b054542b359763371dd853a031442c074722a443354d321062103db71583e1584ea81a134310366819a284364aa923d2f121180722c23215392916b29035180711c211381aea13360452567819c093524ce828d583162e571000a5413dd81951511e4ce71503506413091610031433771616f105352c1c0151140da72617731368da09b4201720573111a12190b0e100f0905160c171d0408150718060120021f0a1c241b14212a05\"}', 1, 0, 0, '2024-10-03 14:58:08', '2024-10-03 14:09:58', '2024-10-03 14:09:58'),
(5451, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-10-03 14:58:09', '2024-10-03 14:10:00', '2024-10-03 14:10:00'),
(5452, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-03 14:58:10', '2024-10-03 14:10:24', '2024-10-03 14:10:24'),
(5453, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-03 14:58:10', '2024-10-03 14:13:35', '2024-10-03 14:13:35'),
(5454, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:11', '2024-10-03 14:13:39', '2024-10-03 14:13:39'),
(5455, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:11', '2024-10-03 14:13:45', '2024-10-03 14:13:45'),
(5456, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-03 14:58:12', '2024-10-03 14:13:51', '2024-10-03 14:13:51'),
(5457, 'GTLD190013', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 1, 0, 0, '2024-10-03 14:58:12', '2024-10-03 14:13:53', '2024-10-03 14:13:53'),
(5458, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 14:58:12', '2024-10-03 14:14:08', '2024-10-03 14:14:08'),
(5459, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 14:59:15', '2024-10-03 14:14:17', '2024-10-03 14:14:17'),
(5460, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-03 15:00:19', '2024-10-03 14:15:10', '2024-10-03 14:15:10');
INSERT INTO `machine_command` (`id`, `serial`, `name`, `content`, `status`, `send_status`, `err_count`, `run_time`, `gmt_crate`, `gmt_modified`) VALUES
(5461, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 15:01:24', '2024-10-03 14:15:31', '2024-10-03 14:15:31'),
(5462, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 15:03:28', '2024-10-03 14:15:34', '2024-10-03 14:15:34'),
(5463, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":1,\"backupnum\":0}', 0, 1, 3, '2024-10-03 15:06:44', '2024-10-03 14:15:39', '2024-10-03 14:15:39'),
(5464, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-03 15:07:48', '2024-10-03 14:16:08', '2024-10-03 14:16:08'),
(5465, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-03 00:00:00\",\"endtime\":\"2024-10-03 00:00:00\"}]}', 0, 1, 3, '2024-10-03 15:08:52', '2024-10-03 14:16:35', '2024-10-03 14:16:35'),
(5466, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 15:09:56', '2024-10-03 14:16:41', '2024-10-03 14:16:41'),
(5467, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 15:11:00', '2024-10-03 14:17:03', '2024-10-03 14:17:03'),
(5468, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 15:14:04', '2024-10-03 14:17:20', '2024-10-03 14:17:20'),
(5469, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 15:15:08', '2024-10-03 14:17:24', '2024-10-03 14:17:24'),
(5470, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 15:16:12', '2024-10-03 14:19:13', '2024-10-03 14:19:13'),
(5471, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 15:17:46', '2024-10-03 14:19:29', '2024-10-03 14:19:29'),
(5472, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 15:18:50', '2024-10-03 14:19:38', '2024-10-03 14:19:38'),
(5473, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-03 15:19:54', '2024-10-03 14:19:45', '2024-10-03 14:19:45'),
(5474, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 15:20:58', '2024-10-03 14:19:57', '2024-10-03 14:19:57'),
(5475, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-03 16:13:02', '2024-10-03 14:20:47', '2024-10-03 14:20:47'),
(5476, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 16:14:06', '2024-10-03 14:21:00', '2024-10-03 14:21:00'),
(5477, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-03 16:14:08', '2024-10-03 14:21:07', '2024-10-03 14:21:07'),
(5478, '', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 0, 0, NULL, '2024-10-03 14:25:24', '2024-10-03 14:25:24'),
(5479, '', 'getdevinfo', '{\"cmd\":\"getdevinfo\"}', 0, 0, 0, NULL, '2024-10-03 14:25:26', '2024-10-03 14:25:26'),
(5480, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 16:15:11', '2024-10-03 14:27:27', '2024-10-03 14:27:27'),
(5481, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 16:16:15', '2024-10-03 14:27:33', '2024-10-03 14:27:33'),
(5482, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-03 16:17:19', '2024-10-03 14:27:48', '2024-10-03 14:27:48'),
(5483, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 16:18:23', '2024-10-03 14:27:55', '2024-10-03 14:27:55'),
(5484, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-03 16:19:27', '2024-10-03 14:28:54', '2024-10-03 14:28:54'),
(5485, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-03 16:20:31', '2024-10-03 14:29:01', '2024-10-03 14:29:01'),
(5486, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":2,\"backupnum\":0}', 0, 1, 3, '2024-10-03 16:21:35', '2024-10-03 14:29:15', '2024-10-03 14:29:15'),
(5487, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 16:22:39', '2024-10-03 14:29:29', '2024-10-03 14:29:29'),
(5488, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 16:23:43', '2024-10-03 14:30:37', '2024-10-03 14:30:37'),
(5489, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-03 16:24:47', '2024-10-03 14:30:43', '2024-10-03 14:30:43'),
(5490, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 0, 1, 3, '2024-10-03 16:25:51', '2024-10-03 14:31:01', '2024-10-03 14:31:01'),
(5491, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 0, 1, 3, '2024-10-03 16:26:55', '2024-10-03 14:31:03', '2024-10-03 14:31:03'),
(5492, 'GTLD190013', 'getdevlock', '{\"cmd\":\"getdevlock\"}', 0, 1, 3, '2024-10-03 16:27:59', '2024-10-03 14:31:26', '2024-10-03 14:31:26'),
(5493, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 0, 1, 3, '2024-10-03 16:29:03', '2024-10-03 14:31:30', '2024-10-03 14:31:30'),
(5494, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":2,\"backupnum\":13}', 0, 1, 3, '2024-10-03 16:30:07', '2024-10-03 14:31:36', '2024-10-03 14:31:36'),
(5495, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 0, 1, 3, '2024-10-03 16:31:11', '2024-10-03 14:31:41', '2024-10-03 14:31:41'),
(5496, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 0, 1, 3, '2024-10-03 16:32:15', '2024-10-03 14:31:43', '2024-10-03 14:31:43'),
(5497, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 0, 1, 3, '2024-10-03 16:33:19', '2024-10-03 14:31:56', '2024-10-03 14:31:56'),
(5498, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-03 16:34:23', '2024-10-03 14:33:13', '2024-10-03 14:33:13'),
(5499, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 2, '2024-10-06 17:55:35', '2024-10-03 14:33:26', '2024-10-03 14:33:26'),
(5500, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:55:35', '2024-10-03 14:33:51', '2024-10-03 14:33:51'),
(5501, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:55:36', '2024-10-03 14:33:54', '2024-10-03 14:33:54'),
(5502, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:55:36', '2024-10-03 14:34:04', '2024-10-03 14:34:04'),
(5503, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-04 00:00:00\",\"endtime\":\"2024-10-05 00:00:00\"}]}', 1, 0, 0, '2024-10-06 17:55:37', '2024-10-03 14:36:34', '2024-10-03 14:36:34'),
(5504, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:55:37', '2024-10-03 14:36:38', '2024-10-03 14:36:38'),
(5505, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:55:37', '2024-10-03 14:36:43', '2024-10-03 14:36:43'),
(5506, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:55:38', '2024-10-03 14:37:33', '2024-10-03 14:37:33'),
(5507, 'GTLD190013', 'getdevlock', '{\"cmd\":\"getdevlock\"}', 0, 1, 3, '2024-10-06 17:56:41', '2024-10-03 14:37:42', '2024-10-03 14:37:42'),
(5508, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 1, '2024-10-06 17:57:03', '2024-10-03 14:37:58', '2024-10-03 14:37:58'),
(5509, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:57:04', '2024-10-03 14:38:05', '2024-10-03 14:38:05'),
(5510, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:57:04', '2024-10-03 14:47:33', '2024-10-03 14:47:33'),
(5511, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:57:05', '2024-10-03 14:47:39', '2024-10-03 14:47:39'),
(5512, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 0, '2024-10-06 17:57:05', '2024-10-03 14:47:49', '2024-10-03 14:47:49'),
(5513, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-06 17:57:05', '2024-10-03 14:48:52', '2024-10-03 14:48:52'),
(5514, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:57:06', '2024-10-03 14:48:55', '2024-10-03 14:48:55'),
(5515, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:57:06', '2024-10-03 14:49:04', '2024-10-03 14:49:04'),
(5516, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 1, '2024-10-06 17:57:34', '2024-10-03 14:49:37', '2024-10-03 14:49:37'),
(5517, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:57:34', '2024-10-03 14:49:55', '2024-10-03 14:49:55'),
(5518, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-06 17:57:35', '2024-10-03 14:56:49', '2024-10-03 14:56:49'),
(5519, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:57:36', '2024-10-03 14:57:35', '2024-10-03 14:57:35'),
(5520, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 17:57:37', '2024-10-03 14:57:39', '2024-10-03 14:57:39'),
(5521, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-03 00:00:00\",\"endtime\":\"2024-10-05 00:00:00\"}]}', 1, 0, 0, '2024-10-06 17:57:37', '2024-10-03 14:57:56', '2024-10-03 14:57:56'),
(5522, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:57:38', '2024-10-03 14:58:40', '2024-10-03 14:58:40'),
(5523, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:57:38', '2024-10-03 14:58:44', '2024-10-03 14:58:44'),
(5524, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:57:39', '2024-10-03 14:59:53', '2024-10-03 14:59:53'),
(5525, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:57:39', '2024-10-03 15:00:10', '2024-10-03 15:00:10'),
(5526, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:57:39', '2024-10-03 15:00:22', '2024-10-03 15:00:22'),
(5527, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:57:40', '2024-10-03 15:00:36', '2024-10-03 15:00:36'),
(5528, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:57:40', '2024-10-03 15:00:41', '2024-10-03 15:00:41'),
(5529, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 17:57:40', '2024-10-03 15:00:52', '2024-10-03 15:00:52'),
(5530, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-06 17:57:41', '2024-10-03 15:01:15', '2024-10-03 15:01:15'),
(5531, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-06 17:57:42', '2024-10-03 15:01:24', '2024-10-03 15:01:24'),
(5532, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 2, '2024-10-06 17:58:24', '2024-10-03 15:01:45', '2024-10-03 15:01:45'),
(5533, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-06 17:58:24', '2024-10-03 15:01:47', '2024-10-03 15:01:47'),
(5534, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 2, '2024-10-06 17:59:06', '2024-10-03 15:02:29', '2024-10-03 15:02:29'),
(5535, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-06 17:59:07', '2024-10-03 15:02:31', '2024-10-03 15:02:31'),
(5536, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 1, '2024-10-06 17:59:46', '2024-10-03 15:07:25', '2024-10-03 15:07:25'),
(5537, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-06 17:59:47', '2024-10-03 15:07:28', '2024-10-03 15:07:28'),
(5538, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 2, '2024-10-06 18:01:52', '2024-10-03 15:08:52', '2024-10-03 15:08:52'),
(5539, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 1, '2024-10-06 18:02:14', '2024-10-03 15:09:29', '2024-10-03 15:09:29'),
(5540, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:02:15', '2024-10-03 15:09:41', '2024-10-03 15:09:41'),
(5541, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:02:15', '2024-10-03 15:10:11', '2024-10-03 15:10:11'),
(5542, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:02:16', '2024-10-03 15:10:14', '2024-10-03 15:10:14'),
(5543, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:02:16', '2024-10-03 15:10:34', '2024-10-03 15:10:34'),
(5544, 'GTLD190013', 'getdevlock', '{\"cmd\":\"getdevlock\"}', 0, 1, 3, '2024-10-06 18:03:20', '2024-10-03 15:10:39', '2024-10-03 15:10:39'),
(5545, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 1, '2024-10-06 18:03:43', '2024-10-03 15:10:55', '2024-10-03 15:10:55'),
(5546, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 0, '2024-10-06 18:03:43', '2024-10-03 15:11:40', '2024-10-03 15:11:40'),
(5547, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-06 18:03:43', '2024-10-03 15:11:47', '2024-10-03 15:11:47'),
(5548, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 2, '2024-10-06 18:04:26', '2024-10-03 15:13:24', '2024-10-03 15:13:24'),
(5549, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-06 18:04:26', '2024-10-03 15:13:27', '2024-10-03 15:13:27'),
(5550, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 2, '2024-10-06 18:05:09', '2024-10-03 15:13:29', '2024-10-03 15:13:29'),
(5551, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:05:09', '2024-10-03 15:13:36', '2024-10-03 15:13:36'),
(5552, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-03 00:00:00\",\"endtime\":\"2024-10-12 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:05:10', '2024-10-03 15:14:38', '2024-10-03 15:14:38'),
(5553, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:05:10', '2024-10-03 15:14:44', '2024-10-03 15:14:44'),
(5554, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:05:11', '2024-10-03 15:14:49', '2024-10-03 15:14:49'),
(5555, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:05:11', '2024-10-03 15:14:59', '2024-10-03 15:14:59'),
(5556, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 0, '2024-10-06 18:05:12', '2024-10-03 15:15:33', '2024-10-03 15:15:33'),
(5557, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:05:12', '2024-10-03 15:15:40', '2024-10-03 15:15:40'),
(5558, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:05:12', '2024-10-03 15:15:48', '2024-10-03 15:15:48'),
(5559, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:05:13', '2024-10-03 15:15:56', '2024-10-03 15:15:56'),
(5560, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-06 18:05:14', '2024-10-03 15:16:11', '2024-10-03 15:16:11'),
(5561, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-03 00:00:00\",\"endtime\":\"2024-10-05 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:05:14', '2024-10-03 15:17:33', '2024-10-03 15:17:33'),
(5562, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:05:15', '2024-10-03 15:18:11', '2024-10-03 15:18:11'),
(5563, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:05:15', '2024-10-03 15:18:29', '2024-10-03 15:18:29'),
(5564, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:05:15', '2024-10-03 15:18:36', '2024-10-03 15:18:36'),
(5565, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:05:16', '2024-10-03 15:21:26', '2024-10-03 15:21:26'),
(5566, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-06 18:05:17', '2024-10-03 16:10:37', '2024-10-03 16:10:37'),
(5567, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 0, '2024-10-06 18:05:17', '2024-10-03 16:10:58', '2024-10-03 16:10:58'),
(5568, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-06 18:05:17', '2024-10-03 16:11:01', '2024-10-03 16:11:01'),
(5569, 'GTLD190013', 'getdevlock', '{\"cmd\":\"getdevlock\"}', 0, 1, 3, '2024-10-06 18:06:20', '2024-10-03 16:11:29', '2024-10-03 16:11:29'),
(5570, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 1, '2024-10-06 18:06:43', '2024-10-03 16:11:37', '2024-10-03 16:11:37'),
(5571, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:06:43', '2024-10-03 16:11:42', '2024-10-03 16:11:42'),
(5572, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:06:44', '2024-10-03 16:12:16', '2024-10-03 16:12:16'),
(5573, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:06:44', '2024-10-03 16:12:50', '2024-10-03 16:12:50'),
(5574, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":}', 0, 1, 3, '2024-10-06 18:11:18', '2024-10-03 16:12:58', '2024-10-03 16:12:58'),
(5575, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:11:20', '2024-10-03 16:13:05', '2024-10-03 16:13:05'),
(5576, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:11:20', '2024-10-03 16:13:07', '2024-10-03 16:13:07'),
(5577, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-03 00:00:00\",\"endtime\":\"2024-10-05 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:11:21', '2024-10-03 16:13:18', '2024-10-03 16:13:18'),
(5578, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:11:21', '2024-10-03 16:13:32', '2024-10-03 16:13:32'),
(5579, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:11:21', '2024-10-03 16:14:19', '2024-10-03 16:14:19'),
(5580, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:11:22', '2024-10-03 16:14:23', '2024-10-03 16:14:23'),
(5581, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:22', '2024-10-03 16:15:17', '2024-10-03 16:15:17'),
(5582, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:22', '2024-10-03 16:15:31', '2024-10-03 16:15:31'),
(5583, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:23', '2024-10-03 16:15:46', '2024-10-03 16:15:46'),
(5584, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:23', '2024-10-03 16:15:54', '2024-10-03 16:15:54'),
(5585, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:23', '2024-10-03 16:16:13', '2024-10-03 16:16:13'),
(5586, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:24', '2024-10-03 16:16:30', '2024-10-03 16:16:30'),
(5587, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:24', '2024-10-03 17:20:26', '2024-10-03 17:20:26'),
(5588, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:25', '2024-10-03 17:20:30', '2024-10-03 17:20:30'),
(5589, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:25', '2024-10-03 17:22:42', '2024-10-03 17:22:42'),
(5590, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:25', '2024-10-04 12:22:24', '2024-10-04 12:22:24'),
(5591, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:26', '2024-10-04 12:22:27', '2024-10-04 12:22:27'),
(5592, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:26', '2024-10-04 13:16:38', '2024-10-04 13:16:38'),
(5593, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:26', '2024-10-04 13:16:41', '2024-10-04 13:16:41'),
(5594, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:27', '2024-10-05 05:13:25', '2024-10-05 05:13:25'),
(5595, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:28', '2024-10-05 05:18:39', '2024-10-05 05:18:39'),
(5596, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:28', '2024-10-05 05:37:54', '2024-10-05 05:37:54'),
(5597, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:11:28', '2024-10-05 20:07:18', '2024-10-05 20:07:18'),
(5598, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-06 18:11:39', '2024-10-05 20:08:53', '2024-10-05 20:08:53'),
(5599, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 2, '2024-10-06 18:12:23', '2024-10-05 20:09:02', '2024-10-05 20:09:02'),
(5600, 'GTLD190013', 'getdevlock', '{\"cmd\":\"getdevlock\"}', 0, 1, 3, '2024-10-06 18:13:26', '2024-10-05 20:09:09', '2024-10-05 20:09:09'),
(5601, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 1, '2024-10-06 18:17:15', '2024-10-05 20:09:35', '2024-10-05 20:09:35'),
(5602, 'GTLD190013', 'opendoor', '{\"cmd\":\"opendoor\",\"doornum\":1}', 1, 0, 0, '2024-10-06 18:17:15', '2024-10-05 20:09:42', '2024-10-05 20:09:42'),
(5603, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"Mozakkir\",\"backupnum\":0,\"admin\":0,\"record\":\"c51367008c881a820fc9f9c7a688c2aebff7f88320890abdf83e17c285872b0e37cbf5ca99898b5107fa08411986cb7d093e281a21870bad007fc6863b84fbeecfc5a5459987dc090001b6429a88f401e079d8439589fc55087e18c393889469e88028439088fd19f83e0b844584eb45d7ffc4c29785b4c1f8387a4a94870cd1cf7a1a438085bd0ef989fc8b8386552df949fc08b5846b99ff7ff803(328)016b62278df3354fa561774b96991b32414f31a7173565f496f23132bff4f3bf(80)0e67ef5e623376616f3a22323660cf5a5441a986b55c53d1b852f82123919980002f1243628083164302b5a06d14151698513021855072a28d2563539d80c00d4005aa806d0c71610380dd4a204826c26d0053522570(96)06080503090b0f070e0401121102(16)ed7d\"}', 1, 0, 0, '2024-10-06 18:17:15', '2024-10-05 20:09:47', '2024-10-05 20:09:47'),
(5604, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":1,\"backupnum\":0}', 1, 0, 0, '2024-10-06 18:17:16', '2024-10-05 20:09:50', '2024-10-05 20:09:50'),
(5605, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:17:16', '2024-10-05 20:09:53', '2024-10-05 20:09:53'),
(5606, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 0, '2024-10-06 18:17:17', '2024-10-05 20:09:59', '2024-10-05 20:09:59'),
(5607, 'GTLD190013', 'getuserinfo', '{\"cmd\":\"getuserinfo\",\"enrollid\":1,\"backupnum\":0}', 1, 0, 0, '2024-10-06 18:17:17', '2024-10-05 20:10:06', '2024-10-05 20:10:06'),
(5608, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-06 18:17:18', '2024-10-06 17:56:10', '2024-10-06 17:56:10'),
(5609, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:17:19', '2024-10-06 17:56:48', '2024-10-06 17:56:48'),
(5610, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-10-06 18:17:19', '2024-10-06 17:57:41', '2024-10-06 17:57:41'),
(5611, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-06 00:00:00\",\"endtime\":\"2024-10-06 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:17:20', '2024-10-06 17:58:54', '2024-10-06 17:58:54'),
(5612, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"\",\"backupnum\":0,\"admin\":0,\"record\":\"\"}', 1, 0, 0, '2024-10-06 18:17:20', '2024-10-06 17:59:50', '2024-10-06 17:59:50'),
(5613, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-10-06 18:17:20', '2024-10-06 17:59:52', '2024-10-06 17:59:52'),
(5614, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-10-06 18:17:21', '2024-10-06 18:00:26', '2024-10-06 18:00:26'),
(5615, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"\",\"backupnum\":0,\"admin\":0,\"record\":\"\"}', 1, 0, 0, '2024-10-06 18:17:22', '2024-10-06 18:00:35', '2024-10-06 18:00:35'),
(5616, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-10-06 18:17:22', '2024-10-06 18:00:39', '2024-10-06 18:00:39'),
(5617, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 0, '2024-10-06 18:17:23', '2024-10-06 18:00:55', '2024-10-06 18:00:55'),
(5618, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-06 00:00:00\",\"endtime\":\"2024-10-06 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:17:25', '2024-10-06 18:01:24', '2024-10-06 18:01:24'),
(5619, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"\"}]}', 1, 0, 0, '2024-10-06 18:17:25', '2024-10-06 18:02:40', '2024-10-06 18:02:40'),
(5620, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:17:26', '2024-10-06 18:04:36', '2024-10-06 18:04:36'),
(5621, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-06 18:17:27', '2024-10-06 18:05:10', '2024-10-06 18:05:10'),
(5622, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:17:27', '2024-10-06 18:05:28', '2024-10-06 18:05:28'),
(5623, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-06 18:17:28', '2024-10-06 18:05:36', '2024-10-06 18:05:36'),
(5624, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-06 18:17:28', '2024-10-06 18:05:58', '2024-10-06 18:05:58'),
(5625, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-06 18:17:29', '2024-10-06 18:06:08', '2024-10-06 18:06:08'),
(5626, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:17:29', '2024-10-06 18:07:35', '2024-10-06 18:07:35'),
(5627, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-06 18:17:30', '2024-10-06 18:10:58', '2024-10-06 18:10:58'),
(5628, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:17:30', '2024-10-06 18:12:46', '2024-10-06 18:12:46'),
(5629, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-06 18:17:31', '2024-10-06 18:12:53', '2024-10-06 18:12:53'),
(5630, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-06 18:17:31', '2024-10-06 18:13:07', '2024-10-06 18:13:07'),
(5631, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":2}', 1, 0, 0, '2024-10-06 18:17:31', '2024-10-06 18:13:17', '2024-10-06 18:13:17'),
(5632, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-06 18:17:32', '2024-10-06 18:16:18', '2024-10-06 18:16:18'),
(5633, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":2,\"backupnum\":13}', 1, 0, 0, '2024-10-06 18:17:33', '2024-10-06 18:16:24', '2024-10-06 18:16:24'),
(5634, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 18:17:33', '2024-10-06 18:16:47', '2024-10-06 18:16:47'),
(5635, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:17:33', '2024-10-06 18:16:55', '2024-10-06 18:16:55'),
(5636, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"Mozakkir\",\"backupnum\":0,\"admin\":0,\"record\":\"c51367008c881a820fc9f9c7a688c2aebff7f88320890abdf83e17c285872b0e37cbf5ca99898b5107fa08411986cb7d093e281a21870bad007fc6863b84fbeecfc5a5459987dc090001b6429a88f401e079d8439589fc55087e18c393889469e88028439088fd19f83e0b844584eb45d7ffc4c29785b4c1f8387a4a94870cd1cf7a1a438085bd0ef989fc8b8386552df949fc08b5846b99ff7ff803(328)016b62278df3354fa561774b96991b32414f31a7173565f496f23132bff4f3bf(80)0e67ef5e623376616f3a22323660cf5a5441a986b55c53d1b852f82123919980002f1243628083164302b5a06d14151698513021855072a28d2563539d80c00d4005aa806d0c71610380dd4a204826c26d0053522570(96)06080503090b0f070e0401121102(16)ed7d\"}', 1, 0, 0, '2024-10-06 18:17:39', '2024-10-06 18:17:38', '2024-10-06 18:17:38'),
(5637, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 18:17:45', '2024-10-06 18:17:43', '2024-10-06 18:17:43'),
(5638, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-06 19:57:20', '2024-10-06 18:47:37', '2024-10-06 18:47:37'),
(5639, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 19:57:20', '2024-10-06 18:47:58', '2024-10-06 18:47:58'),
(5640, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-06 19:57:21', '2024-10-06 18:48:11', '2024-10-06 18:48:11'),
(5641, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":6,\"backupnum\":13}', 1, 0, 0, '2024-10-06 19:57:22', '2024-10-06 19:52:28', '2024-10-06 19:52:28'),
(5642, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-06 19:57:22', '2024-10-06 19:55:35', '2024-10-06 19:55:35'),
(5643, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":7,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-06 19:57:43', '2024-10-06 19:57:42', '2024-10-06 19:57:42'),
(5644, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":7,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-06 19:57:52', '2024-10-06 19:57:51', '2024-10-06 19:57:51'),
(5645, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":7,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-06 19:57:54', '2024-10-06 19:57:53', '2024-10-06 19:57:53'),
(5646, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":2,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":7,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-06 19:58:04', '2024-10-06 19:58:04', '2024-10-06 19:58:04'),
(5647, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":7,\"backupnum\":13}', 0, 1, 3, '2024-10-07 17:59:21', '2024-10-07 17:58:17', '2024-10-07 17:58:17'),
(5648, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-07 18:00:40', '2024-10-07 17:59:36', '2024-10-07 17:59:36'),
(5649, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-07 18:01:44', '2024-10-07 17:59:47', '2024-10-07 17:59:47'),
(5650, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":0,\"record\":]}', 0, 1, 3, '2024-10-07 18:02:48', '2024-10-07 18:00:03', '2024-10-07 18:00:03'),
(5651, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-07 18:03:52', '2024-10-07 18:00:47', '2024-10-07 18:00:47'),
(5652, 'GTLD190013', 'setdevlock', '{\"cmd\":\"setdevlock\",\"weekzone\":[{\"week\":[{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0}]},{\"week\":[{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0}]},{\"week\":[{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0}]},{\"week\":[{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0}]},{\"week\":[{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0}]},{\"week\":[{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0}]},{\"week\":[{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0}]},{\"week\":[{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0},{\"day\":0}]}]}', 0, 1, 3, '2024-10-07 18:04:56', '2024-10-07 18:03:03', '2024-10-07 18:03:03'),
(5653, 'GTLD190013', 'setdevlock', '{\"cmd\":\"setdevlock\",\"dayzone\":[{\"day\":[{\"section\":\"06:05~06:06\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]}]}', 0, 1, 3, '2024-10-07 18:06:00', '2024-10-07 18:04:19', '2024-10-07 18:04:19'),
(5654, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-08 00:00:00\",\"endtime\":\"2024-10-08 00:00:00\"}]}', 0, 1, 3, '2024-10-07 18:07:04', '2024-10-07 18:04:39', '2024-10-07 18:04:39'),
(5655, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-07 12:11:36', '2024-10-07 12:08:01', '2024-10-07 12:08:01'),
(5656, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":9,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 12:12:40', '2024-10-07 12:08:44', '2024-10-07 12:08:44'),
(5657, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":9,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 12:13:44', '2024-10-07 12:09:21', '2024-10-07 12:09:21'),
(5658, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":9,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 1, 0, 1, '2024-10-07 12:14:08', '2024-10-07 12:09:36', '2024-10-07 12:09:36'),
(5659, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":9,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 12:15:11', '2024-10-07 12:10:00', '2024-10-07 12:10:00'),
(5660, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":9,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 12:16:15', '2024-10-07 12:10:12', '2024-10-07 12:10:12'),
(5661, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":9,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 12:17:19', '2024-10-07 12:10:47', '2024-10-07 12:10:47'),
(5662, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":9,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 12:19:51', '2024-10-07 12:11:18', '2024-10-07 12:11:18'),
(5663, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":9,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 12:19:53', '2024-10-07 12:11:57', '2024-10-07 12:11:57'),
(5664, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":9,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 12:19:53', '2024-10-07 12:12:04', '2024-10-07 12:12:04'),
(5665, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":9,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-08 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 1, 0, 0, '2024-10-07 12:19:53', '2024-10-07 12:12:56', '2024-10-07 12:12:56'),
(5666, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-07 12:19:54', '2024-10-07 12:13:37', '2024-10-07 12:13:37'),
(5667, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":9}', 1, 0, 0, '2024-10-07 12:19:54', '2024-10-07 12:13:51', '2024-10-07 12:13:51'),
(5668, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-07 12:19:54', '2024-10-07 12:14:30', '2024-10-07 12:14:30'),
(5669, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":10,\"name\":\"Name\"}]}', 1, 0, 0, '2024-10-07 12:19:55', '2024-10-07 12:14:36', '2024-10-07 12:14:36'),
(5670, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":2,\"record\":[{\"enrollid\":9,\"name\":\"Mozakkir\"},{\"enrollid\":10,\"name\":\"Name\"}]}', 1, 0, 0, '2024-10-07 12:19:55', '2024-10-07 12:15:20', '2024-10-07 12:15:20'),
(5671, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":10}', 1, 0, 0, '2024-10-07 12:19:56', '2024-10-07 12:15:38', '2024-10-07 12:15:38'),
(5672, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-07 12:19:56', '2024-10-07 12:16:07', '2024-10-07 12:16:07'),
(5673, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 2, '2024-10-07 12:20:39', '2024-10-07 12:16:27', '2024-10-07 12:16:27'),
(5674, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-07 12:20:39', '2024-10-07 12:16:30', '2024-10-07 12:16:30'),
(5675, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":10,\"backupnum\":13}', 1, 0, 2, '2024-10-07 12:21:22', '2024-10-07 12:16:37', '2024-10-07 12:16:37'),
(5676, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":9,\"backupnum\":13}', 1, 0, 0, '2024-10-07 12:21:23', '2024-10-07 12:16:40', '2024-10-07 12:16:40'),
(5677, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-07 12:21:23', '2024-10-07 12:16:42', '2024-10-07 12:16:42'),
(5678, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 1, '2024-10-07 12:23:57', '2024-10-07 12:16:47', '2024-10-07 12:16:47'),
(5679, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 1, '2024-10-07 12:24:19', '2024-10-07 12:16:49', '2024-10-07 12:16:49'),
(5680, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-07 12:24:19', '2024-10-07 12:17:27', '2024-10-07 12:17:27'),
(5681, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 1, 0, 0, '2024-10-07 12:24:23', '2024-10-07 12:19:33', '2024-10-07 12:19:33'),
(5682, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 12:24:23', '2024-10-07 12:19:40', '2024-10-07 12:19:40'),
(5683, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 12:24:23', '2024-10-07 12:20:42', '2024-10-07 12:20:42'),
(5684, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 12:24:24', '2024-10-07 12:21:16', '2024-10-07 12:21:16'),
(5685, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 0, '2024-10-07 12:24:24', '2024-10-07 12:21:27', '2024-10-07 12:21:27'),
(5686, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 12:24:31', '2024-10-07 12:24:31', '2024-10-07 12:24:31'),
(5687, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 12:24:35', '2024-10-07 12:24:34', '2024-10-07 12:24:34'),
(5688, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 12:24:48', '2024-10-07 12:24:47', '2024-10-07 12:24:47'),
(5689, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 12:25:11', '2024-10-07 12:25:09', '2024-10-07 12:25:09'),
(5690, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 1, 0, 0, '2024-10-07 12:25:23', '2024-10-07 12:25:22', '2024-10-07 12:25:22'),
(5691, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 0, 1, 3, '2024-10-07 12:27:59', '2024-10-07 12:26:56', '2024-10-07 12:26:56'),
(5692, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-07 12:29:03', '2024-10-07 12:26:58', '2024-10-07 12:26:58'),
(5693, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 0, 1, 3, '2024-10-07 12:30:07', '2024-10-07 12:27:01', '2024-10-07 12:27:01'),
(5694, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 0, 1, 3, '2024-10-07 12:31:11', '2024-10-07 12:27:04', '2024-10-07 12:27:04'),
(5695, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 0, 1, 3, '2024-10-07 12:32:15', '2024-10-07 12:27:44', '2024-10-07 12:27:44'),
(5696, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 0, 1, 3, '2024-10-07 12:33:19', '2024-10-07 12:27:52', '2024-10-07 12:27:52'),
(5697, 'GTLD190013', 'setdevlock', '{\"cmd\":\"setdevlock\",\"dayzone\":[{\"day\":[{\"section\":\"06:05~06:06\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"12:28~12:29\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]}]}', 0, 1, 3, '2024-10-07 12:34:23', '2024-10-07 12:29:09', '2024-10-07 12:29:09'),
(5698, 'GTLD190013', 'setdevlock', '{\"cmd\":\"setdevlock\",\"dayzone\":[{\"day\":[{\"section\":\"06:05~06:06\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"12:28~12:29\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"12:29~12:31\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]}]}', 0, 1, 3, '2024-10-07 12:35:27', '2024-10-07 12:29:40', '2024-10-07 12:29:40');
INSERT INTO `machine_command` (`id`, `serial`, `name`, `content`, `status`, `send_status`, `err_count`, `run_time`, `gmt_crate`, `gmt_modified`) VALUES
(5699, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-07 12:36:31', '2024-10-07 12:29:59', '2024-10-07 12:29:59'),
(5700, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":3,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 12:39:02', '2024-10-07 12:30:10', '2024-10-07 12:30:10'),
(5701, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":3,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 12:40:06', '2024-10-07 12:30:16', '2024-10-07 12:30:16'),
(5702, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":3,\"weekzone\":3,\"group\":3,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 0, 1, 3, '2024-10-07 12:41:10', '2024-10-07 12:30:42', '2024-10-07 12:30:42'),
(5703, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":3,\"weekzone\":3,\"group\":3,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 0, 1, 3, '2024-10-07 12:42:14', '2024-10-07 12:31:33', '2024-10-07 12:31:33'),
(5704, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":3,\"backupnum\":13}', 0, 1, 3, '2024-10-07 12:43:18', '2024-10-07 12:32:19', '2024-10-07 12:32:19'),
(5705, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-07 12:44:22', '2024-10-07 12:32:40', '2024-10-07 12:32:40'),
(5706, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-07 06:46:08', '2024-10-07 12:34:32', '2024-10-07 12:34:32'),
(5707, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:21', '2024-10-07 12:34:39', '2024-10-07 12:34:39'),
(5708, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:22', '2024-10-07 12:34:52', '2024-10-07 12:34:52'),
(5709, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 1, 0, 0, '2024-10-07 20:49:22', '2024-10-07 12:35:05', '2024-10-07 12:35:05'),
(5710, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:23', '2024-10-07 12:35:35', '2024-10-07 12:35:35'),
(5711, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 0, '2024-10-07 20:49:23', '2024-10-07 12:36:10', '2024-10-07 12:36:10'),
(5712, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:23', '2024-10-07 12:37:09', '2024-10-07 12:37:09'),
(5713, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:24', '2024-10-07 12:37:21', '2024-10-07 12:37:21'),
(5714, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:24', '2024-10-07 12:38:35', '2024-10-07 12:38:35'),
(5715, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:24', '2024-10-07 12:38:44', '2024-10-07 12:38:44'),
(5716, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:25', '2024-10-07 12:39:13', '2024-10-07 12:39:13'),
(5717, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:25', '2024-10-07 12:39:18', '2024-10-07 12:39:18'),
(5718, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:25', '2024-10-07 12:39:32', '2024-10-07 12:39:32'),
(5719, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 0, '2024-10-07 20:49:26', '2024-10-07 12:39:42', '2024-10-07 12:39:42'),
(5720, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 1, 0, 0, '2024-10-07 20:49:26', '2024-10-07 12:40:04', '2024-10-07 12:40:04'),
(5721, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:27', '2024-10-07 12:40:15', '2024-10-07 12:40:15'),
(5722, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 1, 0, 0, '2024-10-07 20:49:27', '2024-10-07 12:43:55', '2024-10-07 12:43:55'),
(5723, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 0, 1, 3, '2024-10-07 06:47:12', '2024-10-07 06:44:13', '2024-10-07 06:44:13'),
(5724, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-07 06:48:16', '2024-10-07 06:44:32', '2024-10-07 06:44:32'),
(5725, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-07 20:49:18', '2024-10-07 06:45:05', '2024-10-07 06:45:05'),
(5726, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-07 20:49:20', '2024-10-07 06:45:18', '2024-10-07 06:45:18'),
(5727, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-07 20:49:20', '2024-10-07 06:45:51', '2024-10-07 06:45:51'),
(5728, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-07 20:49:20', '2024-10-07 06:45:59', '2024-10-07 06:45:59'),
(5729, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-07 20:49:21', '2024-10-07 06:46:11', '2024-10-07 06:46:11'),
(5730, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-07 20:49:21', '2024-10-07 06:46:26', '2024-10-07 06:46:26'),
(5731, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 20:49:33', '2024-10-07 20:49:32', '2024-10-07 20:49:32'),
(5732, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":11,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 02:55:36', '2024-10-07 02:53:52', '2024-10-07 02:53:52'),
(5733, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":11,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 1, '2024-10-07 02:55:58', '2024-10-07 02:54:00', '2024-10-07 02:54:00'),
(5734, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":11,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 02:57:01', '2024-10-07 02:54:45', '2024-10-07 02:54:45'),
(5735, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":11,\"weekzone\":3,\"group\":3,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-07 02:59:30', '2024-10-07 02:55:13', '2024-10-07 02:55:13'),
(5736, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":11,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 03:00:34', '2024-10-07 02:55:37', '2024-10-07 02:55:37'),
(5737, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":11,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 03:00:35', '2024-10-07 02:55:40', '2024-10-07 02:55:40'),
(5738, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":2,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":11,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 03:01:38', '2024-10-07 02:56:32', '2024-10-07 02:56:32'),
(5739, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":11,\"backupnum\":13}', 0, 1, 3, '2024-10-07 03:02:42', '2024-10-07 02:56:55', '2024-10-07 02:56:55'),
(5740, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-07 03:03:46', '2024-10-07 02:56:57', '2024-10-07 02:56:57'),
(5741, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 03:04:50', '2024-10-07 03:00:09', '2024-10-07 03:00:09'),
(5742, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 2, '2024-10-07 03:05:33', '2024-10-07 03:00:15', '2024-10-07 03:00:15'),
(5743, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 03:05:34', '2024-10-07 03:00:38', '2024-10-07 03:00:38'),
(5744, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 03:05:34', '2024-10-07 03:00:53', '2024-10-07 03:00:53'),
(5745, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 1, 0, 0, '2024-10-07 03:05:35', '2024-10-07 03:01:02', '2024-10-07 03:01:02'),
(5746, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 03:05:35', '2024-10-07 03:01:57', '2024-10-07 03:01:57'),
(5747, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-07 03:05:35', '2024-10-07 03:02:18', '2024-10-07 03:02:18'),
(5748, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-07 03:05:36', '2024-10-07 03:02:35', '2024-10-07 03:02:35'),
(5749, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-07 03:05:36', '2024-10-07 03:02:38', '2024-10-07 03:02:38'),
(5750, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-07 03:05:36', '2024-10-07 03:03:49', '2024-10-07 03:03:49'),
(5751, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-07 03:05:37', '2024-10-07 03:03:57', '2024-10-07 03:03:57'),
(5752, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-07 03:05:37', '2024-10-07 03:04:10', '2024-10-07 03:04:10'),
(5753, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-07 03:05:37', '2024-10-07 03:04:28', '2024-10-07 03:04:28'),
(5754, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-07 03:05:38', '2024-10-07 03:05:23', '2024-10-07 03:05:23'),
(5755, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 03:05:56', '2024-10-07 03:05:56', '2024-10-07 03:05:56'),
(5756, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-07 03:06:31', '2024-10-07 03:06:29', '2024-10-07 03:06:29'),
(5757, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Hgh\"}]}', 0, 1, 3, '2024-10-07 03:12:04', '2024-10-07 03:11:00', '2024-10-07 03:11:00'),
(5758, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 03:43:22', '2024-10-07 03:41:10', '2024-10-07 03:41:10'),
(5759, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Hgh\"}]}', 0, 1, 3, '2024-10-07 03:44:26', '2024-10-07 03:41:16', '2024-10-07 03:41:16'),
(5760, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":2,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"}]}', 0, 1, 3, '2024-10-07 03:56:30', '2024-10-07 03:41:37', '2024-10-07 03:41:37'),
(5761, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 03:57:34', '2024-10-07 03:43:36', '2024-10-07 03:43:36'),
(5762, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Hgh\"}]}', 0, 1, 3, '2024-10-07 03:58:38', '2024-10-07 03:43:40', '2024-10-07 03:43:40'),
(5763, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":2,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"}]}', 0, 1, 3, '2024-10-07 03:59:42', '2024-10-07 03:44:02', '2024-10-07 03:44:02'),
(5764, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Hgh\"}]}', 0, 1, 3, '2024-10-07 04:00:46', '2024-10-07 03:44:13', '2024-10-07 03:44:13'),
(5765, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Hgh\"}]}', 0, 1, 3, '2024-10-07 04:03:16', '2024-10-07 03:44:15', '2024-10-07 03:44:15'),
(5766, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-07 04:04:20', '2024-10-07 03:44:20', '2024-10-07 03:44:20'),
(5767, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 1, '2024-10-07 04:04:43', '2024-10-07 03:44:30', '2024-10-07 03:44:30'),
(5768, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Hgh\"}]}', 1, 0, 0, '2024-10-07 04:04:43', '2024-10-07 03:56:35', '2024-10-07 03:56:35'),
(5769, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 04:04:44', '2024-10-07 03:56:40', '2024-10-07 03:56:40'),
(5770, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":2,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"}]}', 1, 0, 0, '2024-10-07 04:04:44', '2024-10-07 03:57:01', '2024-10-07 03:57:01'),
(5771, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Hgh\"}]}', 1, 0, 0, '2024-10-07 04:04:45', '2024-10-07 04:00:49', '2024-10-07 04:00:49'),
(5772, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-07 04:04:46', '2024-10-07 04:01:01', '2024-10-07 04:01:01'),
(5773, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":2,\"backupnum\":13}', 1, 0, 0, '2024-10-07 04:04:46', '2024-10-07 04:01:04', '2024-10-07 04:01:04'),
(5774, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-07 04:04:47', '2024-10-07 04:02:58', '2024-10-07 04:02:58'),
(5775, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 04:04:47', '2024-10-07 04:03:02', '2024-10-07 04:03:02'),
(5776, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":2,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-07 04:04:47', '2024-10-07 04:03:25', '2024-10-07 04:03:25'),
(5777, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":2,\"backupnum\":13}', 1, 0, 0, '2024-10-07 04:04:48', '2024-10-07 04:03:38', '2024-10-07 04:03:38'),
(5778, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 04:04:49', '2024-10-07 04:03:43', '2024-10-07 04:03:43'),
(5779, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-07 04:04:49', '2024-10-07 04:03:49', '2024-10-07 04:03:49'),
(5780, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 04:04:49', '2024-10-07 04:04:27', '2024-10-07 04:04:27'),
(5781, 'GTLD190013', 'getdevlock', '{\"cmd\":\"getdevlock\"}', 0, 1, 3, '2024-10-07 04:05:52', '2024-10-07 04:04:31', '2024-10-07 04:04:31'),
(5782, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 2, '2024-10-07 04:06:36', '2024-10-07 04:04:37', '2024-10-07 04:04:37'),
(5783, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-07 04:06:36', '2024-10-07 04:04:52', '2024-10-07 04:04:52'),
(5784, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Hgh\"}]}', 1, 0, 0, '2024-10-07 04:06:37', '2024-10-07 04:06:04', '2024-10-07 04:06:04'),
(5785, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":2,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"}]}', 1, 0, 0, '2024-10-07 04:06:49', '2024-10-07 04:06:47', '2024-10-07 04:06:47'),
(5786, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":3,\"name\":\"Jakir\"}]}', 1, 0, 1, '2024-10-07 04:08:50', '2024-10-07 04:08:27', '2024-10-07 04:08:27'),
(5787, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-07 04:11:55', '2024-10-07 04:10:37', '2024-10-07 04:10:37'),
(5788, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-07 00:00:00\",\"endtime\":\"2024-10-07 00:00:00\"}]}', 0, 1, 3, '2024-10-07 04:12:59', '2024-10-07 04:11:13', '2024-10-07 04:11:13'),
(5789, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-09 15:51:04', '2024-10-09 15:46:59', '2024-10-09 15:46:59'),
(5790, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-09 15:52:08', '2024-10-09 15:47:18', '2024-10-09 15:47:18'),
(5791, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-09 15:55:12', '2024-10-09 15:48:44', '2024-10-09 15:48:44'),
(5792, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-09 15:56:16', '2024-10-09 15:49:00', '2024-10-09 15:49:00'),
(5793, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 1, 0, 2, '2024-10-09 15:57:00', '2024-10-09 15:50:42', '2024-10-09 15:50:42'),
(5794, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-09 15:58:36', '2024-10-09 15:51:04', '2024-10-09 15:51:04'),
(5795, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":4,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 2, '2024-10-09 15:59:19', '2024-10-09 15:51:35', '2024-10-09 15:51:35'),
(5796, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-09 16:00:22', '2024-10-09 15:51:59', '2024-10-09 15:51:59'),
(5797, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-09 16:02:27', '2024-10-09 15:53:14', '2024-10-09 15:53:14'),
(5798, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-09 16:03:31', '2024-10-09 15:53:23', '2024-10-09 15:53:23'),
(5799, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:03:33', '2024-10-09 15:54:42', '2024-10-09 15:54:42'),
(5800, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:03:33', '2024-10-09 15:54:55', '2024-10-09 15:54:55'),
(5801, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":4,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-09 16:03:34', '2024-10-09 15:55:04', '2024-10-09 15:55:04'),
(5802, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":3,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-09 16:03:34', '2024-10-09 15:55:44', '2024-10-09 15:55:44'),
(5803, 'GTLD190013', 'setdevlock', '{\"cmd\":\"setdevlock\",\"dayzone\":[{\"day\":[{\"section\":\"02:57~03:01\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"03:10~03:12\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"08:54~08:55\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]}]}', 1, 0, 0, '2024-10-09 16:03:35', '2024-10-09 15:56:08', '2024-10-09 15:56:08'),
(5804, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":3,\"weekzone\":3,\"group\":3,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-09 16:03:36', '2024-10-09 15:56:37', '2024-10-09 15:56:37'),
(5805, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-09 16:03:36', '2024-10-09 15:57:44', '2024-10-09 15:57:44'),
(5806, 'GTLD190013', 'cleanadmin', '{\"cmd\":\"cleanadmin\"}', 1, 0, 2, '2024-10-09 16:04:19', '2024-10-09 15:57:48', '2024-10-09 15:57:48'),
(5807, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:04:19', '2024-10-09 15:58:40', '2024-10-09 15:58:40'),
(5808, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:04:19', '2024-10-09 15:59:34', '2024-10-09 15:59:34'),
(5809, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-09 16:04:20', '2024-10-09 16:00:01', '2024-10-09 16:00:01'),
(5810, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:04:20', '2024-10-09 16:00:17', '2024-10-09 16:00:17'),
(5811, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:04:21', '2024-10-09 16:00:29', '2024-10-09 16:00:29'),
(5812, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-09 16:04:21', '2024-10-09 16:00:41', '2024-10-09 16:00:41'),
(5813, 'GTLD190013', 'getuserlock', '{\"cmd\":\"getuserlock\",\"enrollid\":1}', 1, 0, 0, '2024-10-09 16:04:22', '2024-10-09 16:00:56', '2024-10-09 16:00:56'),
(5814, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:04:22', '2024-10-09 16:02:13', '2024-10-09 16:02:13'),
(5815, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:04:22', '2024-10-09 16:03:46', '2024-10-09 16:03:46'),
(5816, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:04:23', '2024-10-09 16:03:56', '2024-10-09 16:03:56'),
(5817, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:04:23', '2024-10-09 16:04:10', '2024-10-09 16:04:10'),
(5818, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":2,\"group\":2,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-09 16:07:13', '2024-10-09 16:06:10', '2024-10-09 16:06:10'),
(5819, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":2,\"group\":2,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-09 16:08:17', '2024-10-09 16:07:11', '2024-10-09 16:07:11'),
(5820, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-09 00:00:00\",\"endtime\":\"2024-10-09 00:00:00\"}]}', 0, 1, 3, '2024-10-09 16:09:21', '2024-10-09 16:08:02', '2024-10-09 16:08:02'),
(5821, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-09 16:10:25', '2024-10-09 16:09:01', '2024-10-09 16:09:01'),
(5822, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-09 00:00:00\",\"endtime\":\"2024-10-09 00:00:00\"}]}', 0, 1, 3, '2024-10-09 16:13:07', '2024-10-09 16:12:04', '2024-10-09 16:12:04'),
(5823, 'GTLD190013', 'setdevlock', '{\"cmd\":\"setdevlock\",\"dayzone\":[{\"day\":[{\"section\":\"02:00~03:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]}]}', 1, 0, 0, '2024-10-09 16:14:40', '2024-10-09 16:14:38', '2024-10-09 16:14:38'),
(5824, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:14:56', '2024-10-09 16:14:55', '2024-10-09 16:14:55'),
(5825, 'GTLD190013', 'setdevlock', '{\"cmd\":\"setdevlock\",\"dayzone\":[{\"day\":[{\"section\":\"02:00~03:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"03:00~10:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]},{\"day\":[{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"},{\"section\":\"00:00~00:00\"}]}]}', 1, 0, 0, '2024-10-09 16:16:00', '2024-10-09 16:15:59', '2024-10-09 16:15:59'),
(5826, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Hgh\"}]}', 1, 0, 0, '2024-10-09 16:16:06', '2024-10-09 16:16:05', '2024-10-09 16:16:05'),
(5827, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":2,\"group\":2,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-09 16:16:44', '2024-10-09 16:16:44', '2024-10-09 16:16:44'),
(5828, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":3,\"name\":\"Jakir\"}]}', 0, 1, 3, '2024-10-09 16:18:39', '2024-10-09 16:17:36', '2024-10-09 16:17:36'),
(5829, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":3,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-09 16:19:43', '2024-10-09 16:17:46', '2024-10-09 16:17:46'),
(5830, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":3,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-09 16:19:45', '2024-10-09 16:18:08', '2024-10-09 16:18:08'),
(5831, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":4,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Hgh\"},{\"enrollid\":3,\"name\":\"Jakir\"},{\"enrollid\":4,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-09 16:19:45', '2024-10-09 16:18:42', '2024-10-09 16:18:42'),
(5832, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":3,\"name\":\"Jakir\"}]}', 1, 0, 0, '2024-10-09 16:19:46', '2024-10-09 16:19:31', '2024-10-09 16:19:31'),
(5833, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-09 16:25:22', '2024-10-09 16:24:19', '2024-10-09 16:24:19'),
(5834, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:44:17', '2024-10-10 16:41:12', '2024-10-10 16:41:12'),
(5835, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:31:10', '2024-10-10 16:41:17', '2024-10-10 16:41:17'),
(5836, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:32:14', '2024-10-10 16:41:24', '2024-10-10 16:41:24'),
(5837, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:35:41', '2024-10-10 16:41:35', '2024-10-10 16:41:35'),
(5838, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:37:58', '2024-10-10 16:41:40', '2024-10-10 16:41:40'),
(5839, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:39:02', '2024-10-10 16:41:49', '2024-10-10 16:41:49'),
(5840, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:40:06', '2024-10-10 16:42:13', '2024-10-10 16:42:13'),
(5841, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:41:10', '2024-10-10 16:42:34', '2024-10-10 16:42:34'),
(5842, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:42:14', '2024-10-10 16:42:54', '2024-10-10 16:42:54'),
(5843, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:43:18', '2024-10-10 16:43:24', '2024-10-10 16:43:24'),
(5844, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 1, '2024-10-10 18:43:41', '2024-10-10 16:46:38', '2024-10-10 16:46:38'),
(5845, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:41', '2024-10-10 16:47:28', '2024-10-10 16:47:28'),
(5846, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:41', '2024-10-10 16:47:32', '2024-10-10 16:47:32'),
(5847, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:42', '2024-10-10 16:47:35', '2024-10-10 16:47:35'),
(5848, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:42', '2024-10-10 16:48:14', '2024-10-10 16:48:14'),
(5849, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:42', '2024-10-10 16:48:18', '2024-10-10 16:48:18'),
(5850, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:43', '2024-10-10 18:31:39', '2024-10-10 18:31:39'),
(5851, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:43', '2024-10-10 18:31:53', '2024-10-10 18:31:53'),
(5852, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:43', '2024-10-10 18:31:57', '2024-10-10 18:31:57'),
(5853, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:44', '2024-10-10 18:32:00', '2024-10-10 18:32:00'),
(5854, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:44', '2024-10-10 18:34:55', '2024-10-10 18:34:55'),
(5855, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:45', '2024-10-10 18:34:58', '2024-10-10 18:34:58'),
(5856, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:45', '2024-10-10 18:38:30', '2024-10-10 18:38:30'),
(5857, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:45', '2024-10-10 18:38:46', '2024-10-10 18:38:46'),
(5858, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:46', '2024-10-10 18:40:26', '2024-10-10 18:40:26'),
(5859, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:46', '2024-10-10 18:40:37', '2024-10-10 18:40:37'),
(5860, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:46', '2024-10-10 18:40:43', '2024-10-10 18:40:43'),
(5861, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:47', '2024-10-10 18:42:34', '2024-10-10 18:42:34'),
(5862, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:47', '2024-10-10 18:42:51', '2024-10-10 18:42:51'),
(5863, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:47', '2024-10-10 18:43:10', '2024-10-10 18:43:10'),
(5864, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:48', '2024-10-10 18:43:30', '2024-10-10 18:43:30'),
(5865, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:48', '2024-10-10 18:43:39', '2024-10-10 18:43:39'),
(5866, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:43:48', '2024-10-10 18:43:43', '2024-10-10 18:43:43'),
(5867, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-10 18:43:57', '2024-10-10 18:43:56', '2024-10-10 18:43:56'),
(5868, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:45:35', '2024-10-10 18:44:31', '2024-10-10 18:44:31'),
(5869, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 2, '2024-10-10 18:46:18', '2024-10-10 18:45:15', '2024-10-10 18:45:15'),
(5870, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":4,\"backupnum\":13}', 1, 0, 0, '2024-10-10 18:46:19', '2024-10-10 18:45:31', '2024-10-10 18:45:31'),
(5871, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":3,\"backupnum\":13}', 1, 0, 0, '2024-10-10 18:46:20', '2024-10-10 18:45:34', '2024-10-10 18:45:34'),
(5872, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":2,\"backupnum\":13}', 1, 0, 0, '2024-10-10 18:46:21', '2024-10-10 18:45:36', '2024-10-10 18:45:36'),
(5873, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 1, 0, 0, '2024-10-10 18:46:22', '2024-10-10 18:45:37', '2024-10-10 18:45:37'),
(5874, 'GTLD190013', 'initsys', '{\"cmd\":\"initsys\"}', 1, 0, 0, '2024-10-10 18:46:23', '2024-10-10 18:45:40', '2024-10-10 18:45:40'),
(5875, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 2, '2024-10-10 18:47:06', '2024-10-10 18:46:08', '2024-10-10 18:46:08'),
(5876, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-10 18:47:06', '2024-10-10 18:46:12', '2024-10-10 18:46:12'),
(5877, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 18:47:07', '2024-10-10 18:46:19', '2024-10-10 18:46:19'),
(5878, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 0, 1, 3, '2024-10-10 18:48:10', '2024-10-10 18:46:59', '2024-10-10 18:46:59'),
(5879, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:49:14', '2024-10-10 18:47:26', '2024-10-10 18:47:26'),
(5880, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:50:18', '2024-10-10 18:48:34', '2024-10-10 18:48:34'),
(5881, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 18:51:22', '2024-10-10 18:48:41', '2024-10-10 18:48:41'),
(5882, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 1, 3, '2024-10-10 19:04:26', '2024-10-10 18:48:44', '2024-10-10 18:48:44'),
(5883, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 19:05:30', '2024-10-10 18:48:51', '2024-10-10 18:48:51'),
(5884, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 19:06:34', '2024-10-10 18:54:04', '2024-10-10 18:54:04'),
(5885, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 19:07:38', '2024-10-10 18:55:05', '2024-10-10 18:55:05'),
(5886, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 19:08:42', '2024-10-10 18:57:05', '2024-10-10 18:57:05'),
(5887, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 2, '2024-10-10 19:09:25', '2024-10-10 18:57:21', '2024-10-10 18:57:21'),
(5888, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 1, '2024-10-10 19:09:46', '2024-10-10 18:57:35', '2024-10-10 18:57:35'),
(5889, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:09:47', '2024-10-10 19:04:44', '2024-10-10 19:04:44'),
(5890, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:09:47', '2024-10-10 19:04:57', '2024-10-10 19:04:57'),
(5891, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:09:48', '2024-10-10 19:05:03', '2024-10-10 19:05:03'),
(5892, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:09:48', '2024-10-10 19:09:05', '2024-10-10 19:09:05'),
(5893, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:09:49', '2024-10-10 19:09:26', '2024-10-10 19:09:26'),
(5894, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 19:19:48', '2024-10-10 19:16:30', '2024-10-10 19:16:30'),
(5895, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 19:47:57', '2024-10-10 19:17:22', '2024-10-10 19:17:22'),
(5896, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\"2024-10-11 00:00:00\",\"endtime\":\"2024-10-11 00:00:00\"}]}', 0, 1, 3, '2024-10-10 19:52:15', '2024-10-10 19:17:48', '2024-10-10 19:17:48'),
(5897, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 19:53:25', '2024-10-10 19:17:55', '2024-10-10 19:17:55'),
(5898, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 19:54:29', '2024-10-10 19:18:11', '2024-10-10 19:18:11'),
(5899, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 1, '2024-10-10 19:54:52', '2024-10-10 19:18:17', '2024-10-10 19:18:17'),
(5900, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:52', '2024-10-10 19:18:39', '2024-10-10 19:18:39'),
(5901, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:52', '2024-10-10 19:18:56', '2024-10-10 19:18:56'),
(5902, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:53', '2024-10-10 19:19:03', '2024-10-10 19:19:03'),
(5903, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:53', '2024-10-10 19:19:17', '2024-10-10 19:19:17'),
(5904, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:53', '2024-10-10 19:19:28', '2024-10-10 19:19:28'),
(5905, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:54', '2024-10-10 19:19:44', '2024-10-10 19:19:44'),
(5906, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:54', '2024-10-10 19:47:22', '2024-10-10 19:47:22'),
(5907, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:55', '2024-10-10 19:47:34', '2024-10-10 19:47:34'),
(5908, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:55', '2024-10-10 19:48:05', '2024-10-10 19:48:05'),
(5909, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:55', '2024-10-10 19:49:52', '2024-10-10 19:49:52'),
(5910, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:56', '2024-10-10 19:50:13', '2024-10-10 19:50:13'),
(5911, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:56', '2024-10-10 19:50:21', '2024-10-10 19:50:21'),
(5912, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:56', '2024-10-10 19:50:26', '2024-10-10 19:50:26'),
(5913, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:57', '2024-10-10 19:50:33', '2024-10-10 19:50:33'),
(5914, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:57', '2024-10-10 19:51:37', '2024-10-10 19:51:37'),
(5915, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:58', '2024-10-10 19:51:43', '2024-10-10 19:51:43'),
(5916, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:58', '2024-10-10 19:51:55', '2024-10-10 19:51:55'),
(5917, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:58', '2024-10-10 19:51:59', '2024-10-10 19:51:59'),
(5918, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:59', '2024-10-10 19:52:03', '2024-10-10 19:52:03'),
(5919, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:54:59', '2024-10-10 19:52:20', '2024-10-10 19:52:20'),
(5920, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:55:00', '2024-10-10 19:53:19', '2024-10-10 19:53:19'),
(5921, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 0, '2024-10-10 19:55:00', '2024-10-10 19:53:57', '2024-10-10 19:53:57'),
(5922, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-10 19:55:01', '2024-10-10 19:54:57', '2024-10-10 19:54:57'),
(5923, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":1,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 0, 1, 3, '2024-10-10 19:57:19', '2024-10-10 19:56:16', '2024-10-10 19:56:16'),
(5924, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 1, '2024-10-10 19:57:42', '2024-10-10 19:56:33', '2024-10-10 19:56:33'),
(5925, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-10 05:21:15', '2024-10-10 05:17:33', '2024-10-10 05:17:33'),
(5926, 'GTLD190013', 'setuserinfo', '{\"cmd\":\"setuserinfo\",\"enrollid\":1,\"name\":\"Mozakkir\",\"backupnum\":0,\"admin\":0,\"record\":\"c5175f004a874ab1707fa40b898962ca37cb5649238a6ae9f8be26464784ab19e7c3f74243884b11c01585a6418a2b7dfe6aa6cc1388c3fd311168cb3a85cc25dfc5c8441a887c69a04bf787958aaaad27fff5832a88ab31d8df15e22c8a3b2eff3217c7b2893b91e6a558af448a3bb1fd6ab796df8923c5291cf7e64986d28e387fb385dc87ba56f86ff64eae85fc7efef419023385dca9dfc5fa029388a4fdfe7e39440b8865161fd1f8855485d211efffb7c1cf8a241687db3b52(296)c72f654613538382d67e4373f4ffc37d33121a439a5ff5e2684244fef671316f3ef7586f6d67ff(73)115fd54c43d28859b15641229958190b1320c282e956225011790f591101638b551410c3cc42eb2232719071b51b23d0ce314f0a7028c9816a602542ca6251744a711463123112303263d134213223758f2a5112adb4406100627e713a5c20809861f0097a07ec70(78)040a060e0c00080f070110050d160b0203(13)469c\"}', 1, 0, 0, '2024-10-10 05:21:16', '2024-10-10 05:18:13', '2024-10-10 05:18:13'),
(5927, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":2,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"},{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-10 05:21:16', '2024-10-10 05:18:16', '2024-10-10 05:18:16'),
(5928, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-10 05:21:17', '2024-10-10 05:20:27', '2024-10-10 05:20:27'),
(5929, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":2,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-10 05:21:17', '2024-10-10 05:20:30', '2024-10-10 05:20:30'),
(5930, 'GTLD190013', 'setuserlock', '{\"cmd\":\"setuserlock\",\"count\":1,\"record\":[{\"enrollid\":2,\"weekzone\":1,\"group\":1,\"starttime\":\" 00:00:00\",\"endtime\":\" 00:00:00\"}]}', 1, 0, 0, '2024-10-10 05:22:25', '2024-10-10 05:22:24', '2024-10-10 05:22:24');
INSERT INTO `machine_command` (`id`, `serial`, `name`, `content`, `status`, `send_status`, `err_count`, `run_time`, `gmt_crate`, `gmt_modified`) VALUES
(5931, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:24:01', '2024-10-10 05:22:57', '2024-10-10 05:22:57'),
(5932, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:25:05', '2024-10-10 05:23:14', '2024-10-10 05:23:14'),
(5933, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:26:09', '2024-10-10 05:23:23', '2024-10-10 05:23:23'),
(5934, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:36:15', '2024-10-10 05:32:19', '2024-10-10 05:32:19'),
(5935, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 0, 2, '2024-10-10 05:36:58', '2024-10-10 05:32:30', '2024-10-10 05:32:30'),
(5936, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:38:01', '2024-10-10 05:32:41', '2024-10-10 05:32:41'),
(5937, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:39:05', '2024-10-10 05:32:58', '2024-10-10 05:32:58'),
(5938, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:40:09', '2024-10-10 05:33:25', '2024-10-10 05:33:25'),
(5939, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:41:13', '2024-10-10 05:33:32', '2024-10-10 05:33:32'),
(5940, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:42:17', '2024-10-10 05:33:45', '2024-10-10 05:33:45'),
(5941, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:43:21', '2024-10-10 05:33:53', '2024-10-10 05:33:53'),
(5942, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:44:25', '2024-10-10 05:34:57', '2024-10-10 05:34:57'),
(5943, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:45:29', '2024-10-10 05:35:31', '2024-10-10 05:35:31'),
(5944, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:46:33', '2024-10-10 05:35:51', '2024-10-10 05:35:51'),
(5945, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:47:37', '2024-10-10 05:36:09', '2024-10-10 05:36:09'),
(5946, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:48:41', '2024-10-10 05:36:16', '2024-10-10 05:36:16'),
(5947, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 05:49:45', '2024-10-10 05:39:10', '2024-10-10 05:39:10'),
(5948, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:00:50', '2024-10-10 05:39:24', '2024-10-10 05:39:24'),
(5949, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:01:54', '2024-10-10 05:39:29', '2024-10-10 05:39:29'),
(5950, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:02:58', '2024-10-10 05:39:35', '2024-10-10 05:39:35'),
(5951, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:04:02', '2024-10-10 05:39:50', '2024-10-10 05:39:50'),
(5952, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:05:06', '2024-10-10 05:40:40', '2024-10-10 05:40:40'),
(5953, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:06:10', '2024-10-10 05:40:57', '2024-10-10 05:40:57'),
(5954, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:07:14', '2024-10-10 05:41:51', '2024-10-10 05:41:51'),
(5955, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:08:18', '2024-10-10 05:49:30', '2024-10-10 05:49:30'),
(5956, 'GTLD190013', 'getnewlog', '{\"cmd\":\"getnewlog\",\"stn\":true}', 1, 1, 0, NULL, '2024-10-10 06:13:21', '2024-10-10 06:13:21'),
(5957, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:09:22', '2024-10-10 15:20:18', '2024-10-10 15:20:18'),
(5958, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:10:26', '2024-10-10 15:52:47', '2024-10-10 15:52:47'),
(5959, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:11:30', '2024-10-10 15:53:10', '2024-10-10 15:53:10'),
(5960, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:12:34', '2024-10-10 15:54:11', '2024-10-10 15:54:11'),
(5961, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-10 16:12:35', '2024-10-10 15:54:35', '2024-10-10 15:54:35'),
(5962, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:13:38', '2024-10-10 15:55:23', '2024-10-10 15:55:23'),
(5963, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:14:42', '2024-10-10 15:58:10', '2024-10-10 15:58:10'),
(5964, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":3,\"name\":\"Jakir\"}]}', 0, 1, 3, '2024-10-10 16:15:46', '2024-10-10 16:00:24', '2024-10-10 16:00:24'),
(5965, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":3,\"backupnum\":13}', 0, 1, 3, '2024-10-10 16:16:50', '2024-10-10 16:00:32', '2024-10-10 16:00:32'),
(5966, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":2,\"backupnum\":13}', 0, 1, 3, '2024-10-10 16:17:54', '2024-10-10 16:01:08', '2024-10-10 16:01:08'),
(5967, 'GTLD190013', 'deleteuser', '{\"cmd\":\"deleteuser\",\"enrollid\":1,\"backupnum\":13}', 0, 1, 3, '2024-10-10 16:18:58', '2024-10-10 16:01:10', '2024-10-10 16:01:10'),
(5968, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 0, 1, 3, '2024-10-10 16:20:02', '2024-10-10 16:01:40', '2024-10-10 16:01:40'),
(5969, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-10 17:26:09', '2024-10-10 16:49:27', '2024-10-10 16:49:27'),
(5970, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-10 17:26:09', '2024-10-10 16:52:41', '2024-10-10 16:52:41'),
(5971, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-10 17:26:10', '2024-10-10 17:04:28', '2024-10-10 17:04:28'),
(5972, 'GTLD190013', 'getuserlist', '{\"cmd\":\"getuserlist\",\"stn\":true}', 1, 0, 0, '2024-10-10 17:26:10', '2024-10-10 17:06:49', '2024-10-10 17:06:49'),
(5973, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":1,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-10 17:26:17', '2024-10-10 17:26:16', '2024-10-10 17:26:16'),
(5974, 'GTLD190013', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 1, 0, 0, '2024-10-10 17:30:14', '2024-10-10 17:30:12', '2024-10-10 17:30:12'),
(5975, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":14,\"name\":\"1hhg\"}]}', 1, 0, 0, '2024-10-10 17:31:11', '2024-10-10 17:31:10', '2024-10-10 17:31:10'),
(5976, 'GTLD190013', 'setusername', '{\"cmd\":\"setusername\",\"count\":1,\"record\":[{\"enrollid\":23,\"name\":\"Mozakkir\"}]}', 1, 0, 0, '2024-10-12 16:24:26', '2024-10-10 19:34:51', '2024-10-10 19:34:51'),
(5977, '', 'getalllog', '{\"cmd\":\"getalllog\",\"stn\":true}', 0, 0, 0, NULL, '2024-10-19 16:26:53', '2024-10-19 16:26:53');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `roll_id` int(100) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Triggers `person`
--

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE `records` (
  `id` int(11) NOT NULL,
  `enroll_id` bigint(20) NOT NULL,
  `records_time` datetime NOT NULL,
  `mode` int(11) NOT NULL,
  `intOut` int(11) NOT NULL,
  `event` int(11) NOT NULL,
  `device_serial_num` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Table structure for table `shift_manage`
--

CREATE TABLE `shift_manage` (
  `id` int(60) NOT NULL,
  `shift_code` int(50) NOT NULL,
  `shift_name` varchar(250) NOT NULL,
  `type` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_code` int(11) NOT NULL,
  `database_name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access_day`
--
ALTER TABLE `access_day`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `access_week`
--
ALTER TABLE `access_week`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD UNIQUE KEY `U` (`id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`),
  ADD KEY `company_code` (`company_code`);

--
-- Indexes for table `depertment`
--
ALTER TABLE `depertment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dupbr`
--
ALTER TABLE `dupbr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dupdept`
--
ALTER TABLE `dupdept`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enrollinfo`
--
ALTER TABLE `enrollinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `machine_command`
--
ALTER TABLE `machine_command`
  ADD PRIMARY KEY (`id`,`status`) USING BTREE;

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `records`
--
ALTER TABLE `records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shift_manage`
--
ALTER TABLE `shift_manage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `company_code` (`company_code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;


ALTER TABLE `dupbr`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
  
  
  ALTER TABLE `dupdept`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `depertment`
--
ALTER TABLE `depertment`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `device`
--
ALTER TABLE `device`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `enrollinfo`
--
ALTER TABLE `enrollinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=520;

--
-- AUTO_INCREMENT for table `machine_command`
--
ALTER TABLE `machine_command`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5978;

--
-- AUTO_INCREMENT for table `records`
--
ALTER TABLE `records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `shift_manage`
--
ALTER TABLE `shift_manage`
  MODIFY `id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;


COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
