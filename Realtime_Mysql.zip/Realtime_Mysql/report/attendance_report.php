
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Attendance Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 10px;
            padding: 10px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .report-table th, .report-table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .report-table th {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
        }
        .report-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .report-table tr:hover {
            background-color: #f1f1f1;
        }
        .filter-form {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            gap: 10px;
            flex-wrap: wrap;
        }
        .filter-form input[type="date"],
        .filter-form select,
        .filter-form label {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            max-width: 150px;
        }
        .filter-form button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .filter-form button:hover {
            background-color: #45a049;
        }
        .date-heading {
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Daily Attendance Report</h1>

    <!-- Date and Filter Form -->
    <form class="filter-form" method="post" id="filterForm">
        <div>
            <label for="start_date">From: </label>
            <input type="date" name="start_date" id="start_date">
        </div>
        <div>
            <label for="end_date">To: </label>
            <input type="date" name="end_date" id="end_date">
        </div>
        <div>
            <label for="status">Status: </label>
            <select name="status" id="status">
                <option value="">All</option>
                <option value="Present">Present</option>
                <option value="Absent">Absent</option>
            </select>
        </div>
        <div>
            <label><input type="checkbox" name="filter_times[]" value="early_time"> Early Time</label>
            <label><input type="checkbox" name="filter_times[]" value="los_time"> LOS Time</label>
            <label><input type="checkbox" name="filter_times[]" value="over_time"> Over Time</label>
            <label><input type="checkbox" name="filter_times[]" value="late_time"> Late Time</label>
        </div>
   
        <button type="submit">Load</button>
    </form>

    <!-- Print Button -->
    <button onclick="printReport()">Print Report</button>

    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Database connection
        require"../main/config/config1.php";

        // Base query
        $sql = "SELECT 
                    ar.enroll_id, ar.name, ar.date, ar.in_time, ar.out_time, 
                    IF(ar.roll_id = 0, 'USER', 'MANAGER') AS role, 
                    ar.start_time, ar.end_time,  
                    ar.late_time, ar.early_time, ar.los_time, ar.over_time, 
                    b.branch_name, d.dept_name,
                    sm.shift_name, ar.status
                FROM 
                    attendance_records ar
                JOIN 
                    branch b ON ar.enroll_id = b.id
                JOIN 
                    depertment d ON ar.enroll_id = d.id
                JOIN 
                    shift_manage sm ON ar.enroll_id = sm.id
                WHERE day(ar.date) = day(CURDATE()) "; // Filter for today's date

        // Apply date filter if selected
        if (!empty($_POST['start_date']) && !empty($_POST['end_date'])) {
            $start_date = $_POST['start_date'];
            $end_date = $_POST['end_date'];
            $sql .= " AND ar.date BETWEEN '$start_date' AND '$end_date'";
        }

        // Apply status filter if selected
        if (!empty($_POST['status'])) {
            $status = $_POST['status'];
            $sql .= " AND ar.status = '$status'";
        }

        // Apply time filters if selected
        if (!empty($_POST['filter_times'])) {
            $filter_times = $_POST['filter_times'];
            $time_filters = [];
            foreach ($filter_times as $time) {
                $time_filters[] = "ar.$time IS NOT NULL";
            }
            $sql .= " AND (" . implode(" OR ", $time_filters) . ")";
        }

        $sql .= " ORDER BY ar.date DESC";
        
        $result = $conn->query($sql);

        // Display Date Heading if records found
        if ($result->num_rows > 0) {
            echo "<div class='date-heading'>Date: " . date("Y-m-d") . "</div>";
        }
    ?>

    <!-- Report Table -->
    <table class="report-table">
        <thead>
            <tr>
                <th>Enroll Id</th>
                <th>Name</th>
                <th>Designation</th>
                <th>Branch</th>
                <th>Department</th>
                <th>Shift</th>
                <th>In Time</th>
                <th>Late Time</th>
                <th>Out Time</th>
                <th>Early Time</th>
                <th>LOS Time</th>
                <th>Over Time</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
           <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . htmlspecialchars($row['enroll_id']) . "</td>
                            <td>" . htmlspecialchars($row['name']) . "</td>
                            <td>" . htmlspecialchars($row['role']) . "</td>
                            <td>" . htmlspecialchars($row['branch_name']) . "</td>
                            <td>" . htmlspecialchars($row['dept_name']) . "</td>
                            <td>" . htmlspecialchars($row['shift_name']) . "</td>
                            <td>" . (!empty($row['in_time']) ? date('H:i', strtotime($row['in_time'])) : '') . "</td>
                            <td>" . (!empty($row['late_time']) ? date('H:i', strtotime($row['late_time'])) : '') . "</td>
                            <td>" . (!empty($row['out_time']) ? date('H:i', strtotime($row['out_time'])) : '') . "</td>
                            <td>" . (!empty($row['early_time']) ? date('H:i', strtotime($row['early_time'])) : '') . "</td>
                            <td>" . htmlspecialchars($row['los_time']) . "</td>
                            <td>" . htmlspecialchars($row['over_time']) . "</td>
                            <td>" . htmlspecialchars($row['status']) . "</td>
                        </tr>";
                }
            } else {
                echo "<tr><td colspan='13'>No records found</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
    <?php } ?>
</div>

<script>
    document.getElementById('filterForm').addEventListener('submit', function(event) {
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        if (startDate && endDate && new Date(startDate) > new Date(endDate)) {
            alert('Start date cannot be after end date.');
            event.preventDefault();
        }
    });

    function printReport() {
        window.print();
    }
</script>

<?php
// Database connection
require "../main/config/config1.php"; // Include database configuration

// Function to create the SQL event if it doesn't exist
function createEvent($conn) {
    $sql = "
        DROP EVENT IF EXISTS update_attendance_records;
        CREATE EVENT update_attendance_records
        ON SCHEDULE EVERY 1 SECOND
        DO
        BEGIN
            DELETE ar
            FROM attendance_records ar
            JOIN records r ON ar.enroll_id = r.enroll_id AND DATE(r.records_time) = CURDATE()
            WHERE ar.in_time IS NULL AND ar.date = CURDATE();

            INSERT INTO attendance_records (enroll_id, mode, event, device_serial_num, temperature, image, date, in_time, out_time, status)
            SELECT enroll_id, mode, event, device_serial_num, temperature, image, CURDATE(), TIME(records_time), NULL, 'Present'
            FROM records
            WHERE intOut = 0 
              AND DATE(records_time) = CURDATE()
              AND enroll_id NOT IN (SELECT enroll_id FROM attendance_records WHERE date = CURDATE())
            ON DUPLICATE KEY UPDATE 
                in_time = IF(in_time IS NULL, TIME(records_time), in_time),
                status = 'Present';

            UPDATE attendance_records ar
            JOIN records r ON ar.enroll_id = r.enroll_id AND ar.date = CURDATE()
            SET ar.out_time = TIME(r.records_time)
            WHERE r.intOut = 0 
              AND DATE(r.records_time) = CURDATE()
              AND ar.in_time <> TIME(r.records_time)
              AND ar.out_time IS NULL;

            UPDATE attendance_records ar
            JOIN person p ON ar.enroll_id = p.id
            JOIN records r ON p.id = r.enroll_id AND DATE(r.records_time) = CURDATE()
            SET ar.status = 'Present'
            WHERE ar.date = CURDATE();

            UPDATE attendance_records ar
            SET ar.early_time = CASE 
                                WHEN TIME_TO_SEC(ar.in_time) < TIME_TO_SEC(ar.start_time) 
                                THEN SEC_TO_TIME(TIME_TO_SEC(ar.start_time) - TIME_TO_SEC(ar.in_time))
                                ELSE NULL
                              END,
                ar.late_time = CASE 
                                WHEN TIME_TO_SEC(ar.in_time) > TIME_TO_SEC(ar.start_time) 
                                THEN SEC_TO_TIME(TIME_TO_SEC(ar.in_time) - TIME_TO_SEC(ar.start_time))
                                ELSE NULL
                              END
            WHERE ar.date = CURDATE();
        END;
    ";
    if ($conn->multi_query($sql)) {
        do {
            // Store the first result set
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->more_results() && $conn->next_result());
    } else {
        echo "Error creating event: " . $conn->error;
    }
}

// Call to create the event (consider making this conditional)
createEvent($conn);
?>
</body>
</html>
