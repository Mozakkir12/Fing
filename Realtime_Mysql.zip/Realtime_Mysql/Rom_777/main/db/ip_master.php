<?php
session_start();
$mysql_db = isset($_SESSION['MYSQL_DB']) ? $_SESSION['MYSQL_DB'] : '';

// IP এবং পোর্ট ডিফল্ট মান
$default_ip = '192.168.110.140';
$default_port = '7788';

// ফাইল তৈরি করার জন্য প্রক্রিয়া
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ip =$_POST['ip']; ; // IP এখানে স্থির
    $port = $default_port; // পোর্ট পরিবর্তনযোগ্য নয়

    // কনফিগারেশন কন্টেন্ট তৈরি করা
    $config_content = "<?php\n";
    $config_content .= "define('SERVER_IP', '$ip');\n";
    $config_content .= "define('SERVER_PORT', '$port');\n\n";
    $config_content .= "define('MAX_THREADS', 32);\n\n";
    $config_content .= "define('MYSQL_HOST', 'localhost:3306');\n";
    $config_content .= "define('MYSQL_DB', '$mysql_db');\n";
    $config_content .= "define('MYSQL_PORT', '3306');\n";
    $config_content .= "define('MYSQL_USER', 'root');\n";
    $config_content .= "define('MYSQL_PASS', 'root');\n\n";
    $config_content .= "/*\n";
    $config_content .= "try{\n";
    $config_content .= "    \$pdo = new PDO(\"mysql:host=\".MYSQL_HOST,MYSQL_USER,MYSQL_PASS);\n";
    $config_content .= "    \$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);\n";
    $config_content .= "    \$pdo->exec(\"use \".MYSQL_DB);\n";
    $config_content .= "}catch(PDOException \$e){\n";
    $config_content .= "    echo \$e->getMessage();\n";
    $config_content .= "}\n";
    $config_content .= "*/\n";
    $config_content .= "?>";

    // ফাইল তৈরি করা
    $file_path = 'main/db/config.php';
    if (file_put_contents($file_path, $config_content)) {
        $message = "Ip Address and Port  set successfully!";
    } else {
        $message = "Ip Address not set Successfully";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Config File Creator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        input[type="submit"] {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .message {
            color: green;
            margin-top: 15px;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>

    <h1>Config File Creator</h1>
    <form method="post">
    	   <label for="ip">Ip Address:</label>
<input type="text" id="ip" name="ip" placeholder="192.168.0.1" 
           pattern="^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$" 
           title="দয়া করে একটি বৈধ IPv4 ঠিকানা প্রবেশ করুন (যেমন: 192.168.0.1)" required>

        <label for="port">Port:</label>
        <input type="text" id="port" name="port" value="<?php echo $default_port; ?>" readonly>
        	
        <input type="submit" value="Create Config File">
    </form>

    <?php if (isset($message)): ?>
        <div class="<?php echo isset($error) ? 'error' : 'message'; ?>"><?php echo $message; ?></div>
    <?php endif; ?>
</body>
</html>
