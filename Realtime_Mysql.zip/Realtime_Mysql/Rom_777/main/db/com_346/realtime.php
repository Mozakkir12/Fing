<?php
define('SERVER_IP', '192.168.110.53');
define('SERVER_PORT', '7788');

define('MAX_THREADS', 32);

define('MYSQL_HOST', 'localhost:3306');
define('MYSQL_DB', 'realtime');
define('MYSQL_PORT', '3306');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', 'root');
?>