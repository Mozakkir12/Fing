<?php
require "Rom_777.php";

class PDOTool extends PDO
{
    protected $tabName = ''; //储存表名
    protected $sql = '';//存储最后执行的sql语句
    
    protected $limit = '';//存储limit条件
    protected $order = '';//存储order排序条件
    protected $field = '*';//存储要查询的字段
    
    protected $allFields = [];//存储当前表的所有字段

    public function __construct($tabName)
    {
        parent::__construct('mysql:host='.MYSQL_HOST.';dbname='.MYSQL_DB.';charset=utf8;port='.MYSQL_PORT,MYSQL_USER,MYSQL_PASS);
        $this->tabName = $tabName;
    }

    protected function getFields()
    {
        $sql = "desc {$this->tabName}";
        $stmt = $this->query($sql);
    }

    public function add($data)
    {
        if (empty($data))
            return;

        $keys = join(',',array_keys($data));
        $vals = join("','",$data);
        $sql = "insert into {$this->tabName}({$keys}) values('{$vals}')";
        $this->sql = $sql;
        return $this->exec2($sql);
    }
    
    public function delete($where)
    {
        $sql = "delete from {$this->tabName} {$where}";
        return (int)$this->exec2($sql);
    }

    public function save($data,$where)
    {
        $str = '';
        foreach ($data as $k=>$v) {
            $str .= "`$k`='$v',";
        }
        $str=substr($str,0,-1);
        if (empty($str)) {
            return;
        }
        $str = rtrim($str,'');
        $sql = "update {$this->tabName} set $str {$where}";
        $this->sql = $sql;
        return (int)$this->exec2($sql);
    }
    
    public static function writeLog($save,$type="SQL: ")
    {
        $logFilePath = './log/debug.txt';
        if (is_readable($logFilePath)) {
            $size = filesize($logFilePath);
            if($size>1024*1024*2) //2M
            {
                $logFilePath2 = './log/debug2.txt';
                if (is_readable($logFilePath2))
                    unlink($logFilePath2);
                rename($logFilePath,$logFilePath2);
            }
        }

        if(strlen($save)>200)
            $save=substr($save,0,200);
        file_put_contents($logFilePath,  $type.$save." [".date("Y-m-d H:i:s")."]
",FILE_APPEND);
    }

    public function exec2($sql)
    {
        $save=$sql;
        $this->writeLog($save,"Exc: ");
        $ret= (int)$this->exec($sql);
        return $ret;
    }
    
    public function select($where,$bSave=true)
    {
        $sql = "select {$this->field} from {$this->tabName} {$where} {$this->order} {$this->limit}";
        $this->sql = $sql;
        if($bSave)
        {
            $this->writeLog($sql);
        }
        $stmt = $this->query($sql);
        if ($stmt) {
            return $stmt->fetchAll(2);
        }
        return [];
    }

    public function find($id)
    {
        $sql = "select {$this->field} from {$this->tabName} where id={$id} limit 1";
        $this->sql = $sql;
        $stmt = $this->query($sql);
        if ($stmt) {
            return $stmt->fetch(2);
        }
        return [];
    }

    public function count($where)
    {
        $sql = "select count(*) from {$this->tabName} {$where} limit 1";
        $this->sql = $sql;
        $stmt = $this->query($sql);
        if ($stmt) {
            return (int)$stmt->fetch()[0];
        }
        return 0;
    }

    public function _sql()
    {
        return $this->sql;
    }

    public function limit($str)
    {
        $this->limit = 'limit '.$str;
        return $this;
    }

    public function tableName($str)
    {
        if($this->tabName!=$str)
        {
            $this->tabName = $str;
        }
        $this->order ='';
        $this->field='*';
        return $this;
    }

    public function order($str)
    {
        $this->order = 'order by '.$str;
        return $this;
    }

    public function field($str)
    {
        $this->field = $str;
        return $this;
    }
}
?>